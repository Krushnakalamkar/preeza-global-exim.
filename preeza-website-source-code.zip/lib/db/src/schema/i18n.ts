import { boolean, integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const languages = pgTable("languages", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  direction: text("direction").notNull().default("ltr"),
  enabled: boolean("enabled").notNull().default(true),
  isDefault: boolean("is_default").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("languages_code_idx").on(table.code),
]);

export const translationKeys = pgTable("translation_keys", {
  id: serial("id").primaryKey(),
  key: text("key").notNull(),
  locale: text("locale").notNull(),
  value: text("value").notNull(),
  namespace: text("namespace").notNull().default("common"),
  status: text("status").notNull().default("published"),
  updatedBy: text("updated_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("translation_keys_locale_key_idx").on(table.locale, table.key),
]);

export const productTranslations = pgTable("product_translations", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  locale: text("locale").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  specifications: text("specifications").array().notNull(),
  category: text("category").notNull(),
  origin: text("origin").notNull(),
  markets: text("markets").array().notNull(),
  quality: text("quality").notNull(),
  status: text("status").notNull().default("published"),
  updatedBy: text("updated_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("product_translations_product_locale_idx").on(table.productId, table.locale),
]);

export const newsTranslations = pgTable("news_translations", {
  id: serial("id").primaryKey(),
  newsId: integer("news_id").notNull(),
  locale: text("locale").notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  excerpt: text("excerpt").notNull(),
  body: text("body").notNull(),
  status: text("status").notNull().default("published"),
  updatedBy: text("updated_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("news_translations_news_locale_idx").on(table.newsId, table.locale),
  uniqueIndex("news_translations_locale_slug_idx").on(table.locale, table.slug),
]);

export const insertLanguageSchema = createInsertSchema(languages).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTranslationKeySchema = createInsertSchema(translationKeys).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProductTranslationSchema = createInsertSchema(productTranslations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertNewsTranslationSchema = createInsertSchema(newsTranslations).omit({ id: true, createdAt: true, updatedAt: true });

export type Language = typeof languages.$inferSelect;
export type TranslationKey = typeof translationKeys.$inferSelect;
export type ProductTranslation = typeof productTranslations.$inferSelect;
export type NewsTranslation = typeof newsTranslations.$inferSelect;
export type InsertLanguage = z.infer<typeof insertLanguageSchema>;
export type InsertTranslationKey = z.infer<typeof insertTranslationKeySchema>;
export type InsertProductTranslation = z.infer<typeof insertProductTranslationSchema>;
export type InsertNewsTranslation = z.infer<typeof insertNewsTranslationSchema>;