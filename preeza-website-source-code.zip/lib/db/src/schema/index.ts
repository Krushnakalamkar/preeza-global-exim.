import { boolean, integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
export * from "./i18n";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  specifications: text("specifications").array().notNull(),
  imageUrl: text("image_url").notNull(),
  origin: text("origin").notNull(),
  markets: text("markets").array().notNull(),
  quality: text("quality").notNull(),
  featured: boolean("featured").notNull().default(false),
}, (table) => [uniqueIndex("products_slug_idx").on(table.slug)]);

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
}, (table) => [uniqueIndex("services_slug_idx").on(table.slug)]);

export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  excerpt: text("excerpt").notNull(),
  body: text("body").notNull(),
  imageUrl: text("image_url").notNull(),
  publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
  featured: boolean("featured").notNull().default(false),
}, (table) => [uniqueIndex("news_slug_idx").on(table.slug)]);

export const enquiries = pgTable("enquiries", {
  id: serial("id").primaryKey(),
  enquiryId: text("enquiry_id").notNull(),
  idempotencyKey: text("idempotency_key").notNull(),
  name: text("name").notNull(),
  company: text("company").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  country: text("country").notNull(),
  subject: text("subject").notNull(),
  quantity: text("quantity").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("enquiries_number_idx").on(table.enquiryId),
  uniqueIndex("enquiries_idempotency_idx").on(table.idempotencyKey),
]);

export type Product = typeof products.$inferSelect;
export type Enquiry = typeof enquiries.$inferSelect;