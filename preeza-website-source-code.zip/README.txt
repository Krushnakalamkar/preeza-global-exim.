PREEZA GLOBAL EXIM SOLUTIONS — WEBSITE SOURCE CODE

Included:
- React/Vite Preeza frontend
- Express API server
- Shared API client, API specification, Zod schemas and Drizzle database package
- Current deployment configuration
- Current pnpm workspace configuration
- Local image assets required by the website

Run locally:
1. Install pnpm and Node.js.
2. From the project root, run: pnpm install
3. Configure the required environment variables/secrets in your environment.
4. Start the frontend workflow: pnpm --filter @workspace/preeza-global run dev
5. Start the API workflow separately: pnpm --filter @workspace/api-server run dev

The package intentionally excludes node_modules, dist/build output, screenshots, videos and private secrets.
