# Preeza Global Exim Solutions

Corporate export-import website, product catalogue, enquiry system, and protected content administration portal.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- Public and admin web app: `artifacts/preeza-global`
- API server: `artifacts/api-server`
- Database schema: `lib/db/src/schema`
- API contract: `lib/api-spec/openapi.yaml`
- Brand reference images: `attached_assets/About_us_1789058783227.png`, `Food_page_1789058783374.png`, `Our_products_1789058783436.png`, and `Sample_image_home_1789058783491.png`

## Architecture decisions

- Public catalogue reads and enquiry submissions are unauthenticated; all administration mutations and enquiry views require Clerk authentication.
- OpenAPI is the shared contract for the frontend client and server validation.

## Product

Buyers can explore Preeza's export capabilities, products, markets, quality standards, and insights, then submit trackable trade enquiries. Administrators manage catalogue content and enquiry statuses.

## User preferences

- Apply the four supplied reference images as the visual source of truth across every public page.
- Favor dense corporate catalogue layouts, photographic collages, rectangular panels, navy/gold bands, process diagrams, certification strips, and compact navigation.
- Avoid startup/SaaS styling, excessive whitespace, rounded UI cards, and oversized empty editorial heroes.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
