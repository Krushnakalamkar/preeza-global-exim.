import heroBanner from "@assets/high_definition_hero_banner_1789213926210.png";
import brassProducts from "@assets/brass_products_1789213926325.png";
import potteryImage from "@assets/pottery_image_1789213926371.png";
import artisansCollage from "@assets/Preeza_Artisans_Collage_HD_1789213926408.jpg";
import foodBanner from "@assets/food_banner_1789213926427.png";

export const siteImages = {
  heroBanner,
  brassProducts,
  potteryImage,
  artisansCollage,
  foodBanner,
} as const;