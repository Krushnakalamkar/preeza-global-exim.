type AnalyticsData = Record<string, string | number | boolean>;

declare global {
  interface Window {
    umami?: {
      track(name: string, data?: AnalyticsData): void;
    };
  }
}

export function trackEvent(name: string, data?: AnalyticsData): void {
  if (typeof window === "undefined") return;

  try {
    window.umami?.track(name, data);
  } catch {
    // Analytics must never interrupt a buyer action.
  }
}

export function safeAnalyticsSlug(value: string | null | undefined): string | null {
  return value && /^[a-z0-9-]{1,80}$/.test(value) ? value : null;
}