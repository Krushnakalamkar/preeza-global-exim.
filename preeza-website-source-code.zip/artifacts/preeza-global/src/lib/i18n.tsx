import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useBrowserLocation } from "wouter/use-browser-location";
import type { NavigateOptions } from "wouter";

export type Direction = "ltr" | "rtl";

export interface LanguageDefinition {
  code: string;
  name: string;
  nativeName: string;
  direction: Direction;
}

const RTL_CODES = new Set([
  "ar", "ckb", "dv", "fa", "he", "ku", "ps", "sd", "ug", "ur", "yi",
]);

const LANGUAGE_CODES = [
  "en", "hi", "mr", "ar", "fr", "es", "de", "ja", "zh", "pt", "it", "ru", "nl", "ko", "tr",
  "bn", "gu", "ta", "te", "kn", "ml", "pa", "or", "as", "ne", "ur", "sa", "sd", "si", "th",
  "vi", "id", "ms", "fil", "sw", "af", "am", "az", "be", "bg", "ca", "cs", "cy", "da", "el",
  "et", "eu", "fa", "fi", "ga", "gl", "ha", "he", "hr", "hu", "hy", "is", "ka", "kk", "km",
  "ky", "lo", "lt", "lv", "mk", "mn", "mt", "my", "no", "ro", "sk", "sl", "sq", "sr", "sv",
  "tg", "tk", "uk", "uz", "xh", "yo", "zu", "bs", "br", "co", "eo", "fo", "fy", "gd", "gv",
  "ht", "io", "jv", "la", "lb", "mg", "mi", "mo", "oc", "sm", "sn", "so", "st", "su", "tl",
  "ts", "tt", "vo", "wa", "wo", "yi", "zu", "ak", "as", "av", "ay", "ba", "bho", "bi", "bm",
  "bo", "ceb", "ch", "chk", "crh", "csb", "dak", "dar", "din", "doi", "dz", "ee", "ff", "fj",
  "fon", "gaa", "gn", "gor", "gsw", "guw", "hak", "haw", "hil", "hmn", "ho", "hsb", "iba", "ig",
  "ilo", "inh", "iu", "kaa", "kab", "kac", "kbd", "kha", "kik", "kin", "kmb", "kok", "kos", "krc",
  "kr", "krl", "kum", "kv", "lad", "lez", "lg", "li", "lij", "liv", "lmo", "ln", "lu", "lua", "luy",
  "mad", "mai", "mak", "man", "mas", "mhr", "min", "mni", "mrj", "mwl", "nap", "nds", "new", "nia",
  "niu", "nqo", "nso", "ny", "oc", "om", "osa", "pag", "pam", "pap", "pcm", "pms", "prg", "qu",
  "quc", "rap", "rar", "rm", "rn", "rw", "sah", "sc", "scn", "sco", "se", "sg", "sh", "shn", "si",
  "smn", "so", "srn", "ss", "suk", "sus", "swb", "syr", "szl", "tao", "tet", "tiv", "tkl", "tn",
  "to", "tpi", "trv", "tum", "tvl", "ty", "tyv", "udm", "ve", "war", "wln", "wuu", "yap", "za", "zap",
  "zgh", "zxx",
] as const;

function createLanguage(code: string): LanguageDefinition {
  const displayNames = typeof Intl !== "undefined" && "DisplayNames" in Intl
    ? new Intl.DisplayNames(["en"], { type: "language" })
    : null;
  const name = displayNames?.of(code) || code.toUpperCase();
  const nativeDisplayNames = typeof Intl !== "undefined" && "DisplayNames" in Intl
    ? new Intl.DisplayNames([code], { type: "language" })
    : null;
  const nativeName = nativeDisplayNames?.of(code) || name;
  const baseCode = code.split("-")[0];
  return { code, name, nativeName, direction: RTL_CODES.has(baseCode) ? "rtl" : "ltr" };
}

export const SUPPORTED_LANGUAGES: LanguageDefinition[] = Array.from(
  new Set(LANGUAGE_CODES),
  createLanguage,
);

const LANGUAGE_BY_CODE = new Map(SUPPORTED_LANGUAGES.map((language) => [language.code, language]));
export const DEFAULT_LOCALE = "en";
export const RTL_LOCALES = new Set(SUPPORTED_LANGUAGES.filter((language) => language.direction === "rtl").map((language) => language.code));
const APP_BASE_PATH = import.meta.env.BASE_URL.replace(/\/$/, "");

type MessageValue = string | undefined;
type MessageMap = Record<string, string>;

const englishMessages: MessageMap = {
  "brand.name": "Preeza Global Exim Solutions",
  "brand.tagline": "Connecting Markets Worldwide",
  "nav.home": "Home",
  "nav.about": "About Us",
  "nav.products": "Products",
  "nav.products.all": "All Products",
  "nav.products.food": "Food Ingredients & Nutraceuticals",
  "nav.products.jewellery": "Jewellery Collections",
  "nav.products.handicrafts": "Handicrafts & Home Décor",
  "nav.products.heritage": "Indian Heritage Collections",
  "nav.quality": "Quality & Compliance",
  "nav.company": "Company",
  "nav.why": "Why Preeza?",
  "nav.profile": "Company Profile",
  "nav.markets": "Global Markets",
  "nav.industries": "Industries We Serve",
  "nav.services": "Our Services",
  "nav.insights": "Insights",
  "nav.contact": "Contact Us",
  "nav.enquire": "Enquire Now",
  "nav.mainNavigation": "Main navigation",
  "nav.mobileNavigation": "Mobile navigation",
  "nav.toggle": "Toggle navigation menu",
  "nav.logoAlt": "Preeza Global Exim Solutions — Connecting Markets Worldwide",
  "enquiry.title": "Start a conversation",
  "enquiry.description": "Choose the fastest way to connect with our trade team.",
  "enquiry.whatsapp": "Chat on WhatsApp",
  "enquiry.call": "Call our trade desk",
  "enquiry.form": "Open enquiry form",
  "enquiry.hours": "Trade desk hours: Monday–Saturday, 9:00–18:00 IST",
  "common.loading": "Loading…",
  "common.error": "Something went wrong. Please try again.",
  "common.readMore": "Read more",
  "common.viewAll": "View all",
  "common.back": "Back",
  "common.close": "Close",
  "common.language": "Language",
  "common.translated": "Translated",
  "common.englishFallback": "Showing English while this translation is unavailable.",
  "common.translationUnavailable": "This translation is not published yet.",
  "admin.portal": "Preeza Admin",
  "admin.secure": "Secure administration",
  "admin.dashboard": "Dashboard",
  "admin.products": "Products",
  "admin.enquiries": "Enquiries",
  "admin.content": "Content",
  "admin.languages": "Languages",
  "admin.translations": "Translations",
  "admin.exit": "Exit Portal",
  "admin.translationTitle": "Translation CMS",
  "admin.translationDescription": "Publish UI translations and review missing language coverage.",
  "admin.languageTitle": "Language management",
  "admin.languageDescription": "Enable languages, choose text direction, and set the default locale.",
  "admin.searchTranslations": "Search translation keys",
  "admin.save": "Save changes",
  "admin.published": "Published",
  "admin.draft": "Draft",
  "admin.missing": "Missing",
  "seo.titleSuffix": "Preeza Global Exim Solutions",
  "seo.homeTitle": "Home",
  "seo.homeDescription": "Preeza Global Exim Solutions connects Indian quality products to global markets.",
  "seo.servicesTitle": "Export Services",
  "seo.servicesDescription": "End-to-end sourcing, quality assurance, documentation, logistics and export support from India.",
  "seo.industriesTitle": "Industries We Serve",
  "seo.industriesDescription": "Reliable sourcing and export solutions for food, jewellery, handicrafts, textiles and industrial markets.",
  "seo.marketsTitle": "Global Markets",
  "seo.marketsDescription": "Preeza Global connects verified Indian suppliers with buyers across the Middle East, Europe and Asia.",
  "seo.qualityTitle": "Quality & Compliance",
  "seo.qualityDescription": "Supplier qualification, product inspection, documentation and international compliance for dependable trade.",
  "seo.whyTitle": "Why Preeza Global",
  "seo.whyDescription": "A responsible India sourcing partner built around transparency, quality control and dependable execution.",
  "seo.profileTitle": "Company Profile",
  "seo.profileDescription": "Learn about Preeza Global Exim Solutions, our capabilities and our approach to responsible international trade.",
  "seo.insightsTitle": "Trade Insights",
  "seo.insightsDescription": "Practical perspectives on global sourcing, export compliance, Indian products and international markets.",
  "seo.contactTitle": "Contact Preeza Global",
  "seo.contactDescription": "Contact our trade team or submit a product sourcing and export enquiry.",
  "seo.privacyTitle": "Privacy Policy",
  "seo.privacyDescription": "How Preeza Global Exim Solutions handles website and enquiry information.",
  "seo.termsTitle": "Terms of Use",
  "seo.termsDescription": "Terms governing use of the Preeza Global Exim Solutions website.",
};

const seededMessages: Record<string, MessageMap> = {
  en: englishMessages,
  hi: {
    "nav.home": "होम", "nav.about": "हमारे बारे में", "nav.products": "उत्पाद",
    "nav.quality": "गुणवत्ता और अनुपालन", "nav.company": "कंपनी", "nav.insights": "जानकारी",
    "nav.contact": "संपर्क करें", "nav.enquire": "पूछताछ करें", "enquiry.title": "बातचीत शुरू करें",
    "enquiry.whatsapp": "WhatsApp पर चैट करें", "enquiry.call": "हमारी ट्रेड डेस्क को कॉल करें",
    "enquiry.form": "पूछताछ फॉर्म खोलें", "common.language": "भाषा", "common.loading": "लोड हो रहा है…",
    "common.readMore": "और पढ़ें", "common.viewAll": "सभी देखें", "admin.portal": "प्रीज़ा एडमिन",
    "admin.dashboard": "डैशबोर्ड", "admin.products": "उत्पाद", "admin.enquiries": "पूछताछ",
    "admin.content": "कंटेंट", "admin.languages": "भाषाएँ", "admin.translations": "अनुवाद",
  },
  mr: {
    "nav.home": "मुख्यपृष्ठ", "nav.about": "आमच्याबद्दल", "nav.products": "उत्पादने",
    "nav.quality": "गुणवत्ता आणि अनुपालन", "nav.company": "कंपनी", "nav.insights": "माहिती",
    "nav.contact": "संपर्क", "nav.enquire": "चौकशी करा", "enquiry.title": "संवाद सुरू करा",
    "enquiry.whatsapp": "WhatsApp वर चॅट करा", "enquiry.call": "ट्रेड डेस्कला फोन करा",
    "enquiry.form": "चौकशी फॉर्म उघडा", "common.language": "भाषा", "common.loading": "लोड होत आहे…",
    "common.readMore": "अधिक वाचा", "common.viewAll": "सर्व पहा", "admin.portal": "प्रीझा अॅडमिन",
    "admin.dashboard": "डॅशबोर्ड", "admin.products": "उत्पादने", "admin.enquiries": "चौकशी",
    "admin.content": "सामग्री", "admin.languages": "भाषा", "admin.translations": "अनुवाद",
  },
  ar: {
    "nav.home": "الرئيسية", "nav.about": "من نحن", "nav.products": "المنتجات",
    "nav.quality": "الجودة والامتثال", "nav.company": "الشركة", "nav.insights": "الرؤى",
    "nav.contact": "اتصل بنا", "nav.enquire": "أرسل استفساراً", "enquiry.title": "ابدأ محادثة",
    "enquiry.whatsapp": "الدردشة عبر واتساب", "enquiry.call": "اتصل بمكتب التجارة",
    "enquiry.form": "افتح نموذج الاستفسار", "common.language": "اللغة", "common.loading": "جار التحميل…",
    "common.readMore": "اقرأ المزيد", "common.viewAll": "عرض الكل", "admin.portal": "إدارة بريزا",
    "admin.dashboard": "لوحة التحكم", "admin.products": "المنتجات", "admin.enquiries": "الاستفسارات",
    "admin.content": "المحتوى", "admin.languages": "اللغات", "admin.translations": "الترجمات",
  },
  fr: {
    "nav.home": "Accueil", "nav.about": "À propos", "nav.products": "Produits",
    "nav.quality": "Qualité et conformité", "nav.company": "Entreprise", "nav.insights": "Actualités",
    "nav.contact": "Nous contacter", "nav.enquire": "Demander un devis", "enquiry.title": "Commençons une conversation",
    "enquiry.whatsapp": "Discuter sur WhatsApp", "enquiry.call": "Appeler notre bureau commercial",
    "enquiry.form": "Ouvrir le formulaire", "common.language": "Langue", "common.loading": "Chargement…",
    "common.readMore": "Lire la suite", "common.viewAll": "Tout voir", "admin.portal": "Administration Preeza",
    "admin.dashboard": "Tableau de bord", "admin.products": "Produits", "admin.enquiries": "Demandes",
    "admin.content": "Contenu", "admin.languages": "Langues", "admin.translations": "Traductions",
  },
  es: {
    "nav.home": "Inicio", "nav.about": "Quiénes somos", "nav.products": "Productos",
    "nav.quality": "Calidad y cumplimiento", "nav.company": "Empresa", "nav.insights": "Perspectivas",
    "nav.contact": "Contacto", "nav.enquire": "Solicitar información", "enquiry.title": "Inicie una conversación",
    "enquiry.whatsapp": "Chatear por WhatsApp", "enquiry.call": "Llamar a nuestro equipo comercial",
    "enquiry.form": "Abrir formulario", "common.language": "Idioma", "common.loading": "Cargando…",
    "common.readMore": "Leer más", "common.viewAll": "Ver todo", "admin.portal": "Administración de Preeza",
    "admin.dashboard": "Panel", "admin.products": "Productos", "admin.enquiries": "Consultas",
    "admin.content": "Contenido", "admin.languages": "Idiomas", "admin.translations": "Traducciones",
  },
  de: {
    "nav.home": "Startseite", "nav.about": "Über uns", "nav.products": "Produkte",
    "nav.quality": "Qualität und Compliance", "nav.company": "Unternehmen", "nav.insights": "Einblicke",
    "nav.contact": "Kontakt", "nav.enquire": "Anfrage senden", "enquiry.title": "Gespräch beginnen",
    "enquiry.whatsapp": "Per WhatsApp chatten", "enquiry.call": "Handelsteam anrufen",
    "enquiry.form": "Anfrageformular öffnen", "common.language": "Sprache", "common.loading": "Wird geladen…",
    "common.readMore": "Mehr lesen", "common.viewAll": "Alle ansehen", "admin.portal": "Preeza Verwaltung",
    "admin.dashboard": "Dashboard", "admin.products": "Produkte", "admin.enquiries": "Anfragen",
    "admin.content": "Inhalte", "admin.languages": "Sprachen", "admin.translations": "Übersetzungen",
  },
  ja: {
    "nav.home": "ホーム", "nav.about": "会社概要", "nav.products": "製品", "nav.quality": "品質とコンプライアンス",
    "nav.company": "会社", "nav.insights": "インサイト", "nav.contact": "お問い合わせ", "nav.enquire": "お問い合わせを開始",
    "enquiry.title": "ご相談を始める", "enquiry.whatsapp": "WhatsAppでチャット", "enquiry.call": "営業デスクに電話",
    "enquiry.form": "問い合わせフォームを開く", "common.language": "言語", "common.loading": "読み込み中…",
    "common.readMore": "続きを読む", "common.viewAll": "すべて見る", "admin.portal": "Preeza管理",
    "admin.dashboard": "ダッシュボード", "admin.products": "製品", "admin.enquiries": "お問い合わせ",
    "admin.content": "コンテンツ", "admin.languages": "言語", "admin.translations": "翻訳",
  },
  zh: {
    "nav.home": "首页", "nav.about": "关于我们", "nav.products": "产品", "nav.quality": "质量与合规",
    "nav.company": "公司", "nav.insights": "洞察", "nav.contact": "联系我们", "nav.enquire": "立即咨询",
    "enquiry.title": "开始交流", "enquiry.whatsapp": "通过 WhatsApp 聊天", "enquiry.call": "致电贸易团队",
    "enquiry.form": "打开询价表单", "common.language": "语言", "common.loading": "加载中…",
    "common.readMore": "阅读更多", "common.viewAll": "查看全部", "admin.portal": "Preeza 管理",
    "admin.dashboard": "仪表板", "admin.products": "产品", "admin.enquiries": "询价",
    "admin.content": "内容", "admin.languages": "语言", "admin.translations": "翻译",
  },
};

export function isSupportedLocale(value: string | undefined): value is string {
  return Boolean(value && LANGUAGE_BY_CODE.has(value.toLowerCase()));
}

export function normalizeLocale(value: string | undefined): string {
  if (!value) return DEFAULT_LOCALE;
  const lower = value.toLowerCase().replace("_", "-");
  if (LANGUAGE_BY_CODE.has(lower)) return lower;
  const base = lower.split("-")[0];
  return LANGUAGE_BY_CODE.has(base) ? base : DEFAULT_LOCALE;
}

export function localeFromPath(pathname: string): string | null {
  const firstSegment = pathname.split("/").filter(Boolean)[0];
  return isSupportedLocale(firstSegment) ? normalizeLocale(firstSegment) : null;
}

export function stripLocaleFromPath(pathname: string): string {
  const locale = localeFromPath(pathname);
  if (!locale) return pathname || "/";
  const stripped = pathname.slice(locale.length + 1);
  return stripped ? `/${stripped}` : "/";
}

export function prefixLocale(pathname: string, locale: string): string {
  const path = stripAppBasePath(pathname.startsWith("/") ? pathname : `/${pathname}`);
  const withoutLocale = stripLocaleFromPath(path);
  return locale === DEFAULT_LOCALE ? withoutLocale : `/${locale}${withoutLocale === "/" ? "" : withoutLocale}`;
}

function stripAppBasePath(pathname: string) {
  if (APP_BASE_PATH && pathname.startsWith(APP_BASE_PATH)) {
    return pathname.slice(APP_BASE_PATH.length) || "/";
  }
  return pathname || "/";
}

function withAppBasePath(pathname: string) {
  return APP_BASE_PATH ? `${APP_BASE_PATH}${pathname === "/" ? "" : pathname}` : pathname;
}

function detectInitialLocale(): string {
  if (typeof window === "undefined") return DEFAULT_LOCALE;
  const pathLocale = localeFromPath(stripAppBasePath(window.location.pathname));
  if (pathLocale) return pathLocale;
  const stored = window.localStorage.getItem("preeza-locale");
  if (stored && isSupportedLocale(stored)) return normalizeLocale(stored);
  const browserLocale = window.navigator.languages?.[0] || window.navigator.language;
  return normalizeLocale(browserLocale);
}

interface I18nContextValue {
  locale: string;
  language: LanguageDefinition;
  languages: LanguageDefinition[];
  direction: Direction;
  isFallback: boolean;
  setLocale: (locale: string) => void;
  t: (key: string, variables?: Record<string, string | number>) => string;
  localizedPath: (path: string) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState(detectInitialLocale);
  const [remoteMessages, setRemoteMessages] = useState<MessageMap>({});
  const language = LANGUAGE_BY_CODE.get(locale) || LANGUAGE_BY_CODE.get(DEFAULT_LOCALE)!;

  useEffect(() => {
    const pathLocale = localeFromPath(stripAppBasePath(window.location.pathname));
    if (pathLocale && pathLocale !== locale) setLocaleState(pathLocale);
  }, [locale]);

  useEffect(() => {
    window.localStorage.setItem("preeza-locale", locale);
    document.documentElement.lang = locale;
    document.documentElement.dir = language.direction;
    const controller = new AbortController();
    fetch(`/api/translations?locale=${encodeURIComponent(locale)}`, { signal: controller.signal })
      .then((response) => response.ok ? response.json() as Promise<{ messages?: MessageMap }> : null)
      .then((data) => setRemoteMessages(data?.messages || {}))
      .catch(() => setRemoteMessages({}));
    return () => controller.abort();
  }, [language.direction, locale]);

  const setLocale = useCallback((nextLocale: string) => {
    const next = normalizeLocale(nextLocale);
    setLocaleState(next);
    const currentPath = typeof window === "undefined" ? "/" : stripAppBasePath(window.location.pathname);
    const target = prefixLocale(currentPath, next);
    const absoluteTarget = withAppBasePath(target);
    if (typeof window !== "undefined" && absoluteTarget !== window.location.pathname) {
      window.history.pushState({}, "", absoluteTarget + window.location.search + window.location.hash);
      window.dispatchEvent(new PopStateEvent("popstate"));
    }
  }, []);

  const t = useCallback((key: string, variables?: Record<string, string | number>) => {
    const value: MessageValue = remoteMessages[key] || seededMessages[locale]?.[key] || englishMessages[key] || key;
    if (!variables) return value || key;
    return Object.entries(variables).reduce(
      (result, [name, replacement]) => result.replaceAll(`{${name}}`, String(replacement)),
      value || key,
    );
  }, [locale, remoteMessages]);

  const context = useMemo<I18nContextValue>(() => ({
    locale,
    language,
    languages: SUPPORTED_LANGUAGES,
    direction: language.direction,
    isFallback: locale !== DEFAULT_LOCALE && Object.keys(remoteMessages).length === 0 && !seededMessages[locale],
    setLocale,
    t,
    localizedPath: (path) => prefixLocale(path, locale),
  }), [language, locale, remoteMessages, setLocale, t]);

  return <I18nContext.Provider value={context}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) throw new Error("useI18n must be used inside I18nProvider");
  return context;
}

export function useLocaleAwareLocation() {
  const [pathname, navigate] = useBrowserLocation();
  const { locale } = useI18n();
  const routePath = stripAppBasePath(pathname);
  const locationHook: [string, (path: string, ...args: any[]) => any] = [
    withAppBasePath(stripLocaleFromPath(routePath)),
    (to: string, options?: NavigateOptions) => navigate(withAppBasePath(prefixLocale(stripAppBasePath(to), locale)), options),
  ];
  return locationHook;
}
