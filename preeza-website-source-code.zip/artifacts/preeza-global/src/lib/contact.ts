export const QUICK_ENQUIRY_PHONE_DISPLAY = "+91 80072 21786";
export const QUICK_ENQUIRY_PHONE = "+918007221786";
export const QUICK_ENQUIRY_WHATSAPP = "https://wa.me/918007221786";
export const COMPANY_ADDRESS = "MIDC, Kalbhor Nagar, Aishwaryam Ventures, Akurdi, Pune, Maharashtra, India - 411035";
export const COMPANY_ADDRESS_LINES = [
  "MIDC, Kalbhor Nagar",
  "Aishwaryam Ventures, Akurdi",
  "Pune, Maharashtra",
  "India - 411035",
] as const;
export const COMPANY_MAP_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(COMPANY_ADDRESS)}`;