import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe, Building2, MapPin } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";
import { COMPANY_ADDRESS } from "@/lib/contact";

export default function CompanyProfile() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">CORPORATE IDENTITY</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            Company Profile
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-[#17202A]/80 font-medium leading-relaxed">
            An established Indian export house connecting verified products to global markets.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            
            <div className="w-full lg:w-1/3">
              <div className="bg-[#062E66] p-8 text-white shadow-xl">
                <ImageWithFallback src={siteImages.artisansCollage} alt="Indian artisans and heritage craft" className="mb-8 h-44 w-full object-cover opacity-90" />
                <Globe className="w-12 h-12 text-[#F2B51D] mb-6" />
                <h2 className="font-serif text-2xl font-bold mb-6 uppercase">Preeza Global Exim Solutions</h2>
                
                <div className="space-y-6 text-sm">
                  <div>
                    <h4 className="font-bold text-[#F2B51D] text-[10px] uppercase tracking-widest mb-1">Headquarters</h4>
                     <p className="text-blue-100 leading-relaxed" dir="ltr">{COMPANY_ADDRESS}</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#F2B51D] text-[10px] uppercase tracking-widest mb-1">Business Type</h4>
                    <p className="text-blue-100 leading-relaxed">Export House / Sourcing Partner</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#F2B51D] text-[10px] uppercase tracking-widest mb-1">Core Sectors</h4>
                    <p className="text-blue-100 leading-relaxed">Food Ingredients, Jewellery, Handicrafts, Heritage Textiles</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#F2B51D] text-[10px] uppercase tracking-widest mb-1">Key Markets</h4>
                    <p className="text-blue-100 leading-relaxed">GCC, Europe, SE Asia</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full lg:w-2/3">
              <div className="bg-white p-8 md:p-12 border border-gray-200 shadow-sm h-full">
                <h3 className="font-serif text-3xl font-bold text-[#062E66] mb-6 uppercase">Our Heritage & Capability</h3>
                <div className="space-y-6 text-sm text-gray-600 leading-relaxed font-medium">
                  <p>
                    Preeza Global Exim Solutions operates at the intersection of traditional Indian manufacturing excellence and rigorous global trade standards. We were established with a clear mandate: to professionalize, streamline, and secure the sourcing process for international buyers looking to India.
                  </p>
                  <p>
                    Unlike traditional traders, we function as a dedicated sourcing partner on the ground. We understand that global buyers face significant challenges in supplier verification, quality consistency, and export compliance. Our corporate infrastructure is designed specifically to mitigate these risks.
                  </p>
                  <p>
                    Through our deep roots in key industrial and agricultural hubs across India, we have built a vetted network of manufacturers and producers. Every partner in our network is audited for production capability, financial stability, and ethical practices.
                  </p>
                  <p>
                    When you partner with Preeza, you gain an extension of your own procurement team in India—one that is fluent in local business practices but operates with an absolute commitment to international corporate standards.
                  </p>
                </div>

                <div className="mt-12 pt-8 border-t border-gray-100 flex gap-4">
                  <Link href="/about">
                    <Button variant="outline" className="h-12 px-8 text-xs font-bold tracking-widest uppercase border-[#062E66] text-[#062E66] hover:bg-gray-50 rounded-none">
                      Read Our Story
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}