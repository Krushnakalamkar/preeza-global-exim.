import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck, FileCheck, Target, CheckCircle2, Award } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

export default function QualityCompliance() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="relative overflow-hidden bg-[#062E66] py-16 lg:py-20 border-b border-gray-200">
        <ImageWithFallback src={siteImages.brassProducts} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-[#062E66]/70" aria-hidden="true" />
        <div className="container relative z-10 mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">OUR COMMITMENT</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white font-bold leading-tight mb-6 uppercase">
            Quality & Compliance
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-white/85 font-medium leading-relaxed">
            Uncompromising standards, rigorous verification, and strict regulatory adherence across our entire supply chain.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16 mb-16">
            <div>
              <h2 className="font-serif text-3xl font-bold text-[#062E66] mb-6 uppercase">Our Quality Framework</h2>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                We believe that quality is not just an inspection at the end of the line, but a built-in process from supplier selection to final dispatch.
              </p>
              <div className="space-y-4">
                <div className="flex gap-4 items-start p-4 bg-white border border-gray-200 shadow-sm">
                  <Target className="w-6 h-6 text-[#F2B51D] shrink-0" />
                  <div>
                    <h4 className="font-bold text-[#062E66] text-sm uppercase mb-1">Pre-Qualification</h4>
                    <p className="text-xs text-gray-500 leading-relaxed">Stringent capability and certification checks before onboarding any manufacturing partner.</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start p-4 bg-white border border-gray-200 shadow-sm">
                  <CheckCircle2 className="w-6 h-6 text-[#F2B51D] shrink-0" />
                  <div>
                    <h4 className="font-bold text-[#062E66] text-sm uppercase mb-1">In-Process Monitoring</h4>
                    <p className="text-xs text-gray-500 leading-relaxed">Continuous quality tracking during production for bulk orders and specialized products.</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start p-4 bg-white border border-gray-200 shadow-sm">
                  <ShieldCheck className="w-6 h-6 text-[#F2B51D] shrink-0" />
                  <div>
                    <h4 className="font-bold text-[#062E66] text-sm uppercase mb-1">Final Inspection</h4>
                    <p className="text-xs text-gray-500 leading-relaxed">Comprehensive testing and verification before goods are authorized for shipment.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="font-serif text-3xl font-bold text-[#062E66] mb-6 uppercase">Certifications</h2>
              <p className="text-sm text-gray-600 mb-8 leading-relaxed">
                Preeza Global Exim Solutions is registered and compliant with key Indian and international trade authorities.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: "IEC", desc: "Import Export Code" },
                  { name: "GST", desc: "Registered" },
                  { name: "FSSAI", desc: "Compliant" },
                  { name: "MSME", desc: "Registered" },
                  { name: "APEDA", desc: "Registered" },
                  { name: "ISO", desc: "Certified" },
                ].map((cert, i) => (
                  <div key={i} className="bg-white p-6 border border-gray-200 text-center shadow-sm">
                    <Award className="w-8 h-8 text-[#062E66] mx-auto mb-3" />
                    <h4 className="font-bold text-[#062E66] text-sm leading-none mb-1">{cert.name}</h4>
                    <span className="text-[9px] text-gray-500 uppercase tracking-widest">{cert.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </section>

      <section className="bg-[#EEF5FC] py-16 border-t-2 border-[#062E66] text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-3xl font-bold text-[#062E66] mb-4 uppercase">Require Specific Documentation?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto font-medium">Contact our compliance team to discuss the specific regulatory requirements for your destination country.</p>
          <Link href="/contact">
            <Button className="h-12 px-10 text-xs font-bold tracking-widest uppercase bg-[#062E66] hover:bg-[#0A4EA9] text-white rounded-none group">
              Contact Compliance Team <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}