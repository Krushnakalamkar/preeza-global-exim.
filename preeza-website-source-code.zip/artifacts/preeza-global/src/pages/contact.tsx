import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useSearch } from "wouter";
import { useCreateEnquiry } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Mail, Clock, ArrowRight, Building, User } from "lucide-react";
import { useRef, useState } from "react";
import { safeAnalyticsSlug, trackEvent } from "@/lib/analytics";
import { QuickEnquiryDialog } from "@/components/layout/QuickEnquiryDialog";
import {
  QUICK_ENQUIRY_PHONE_DISPLAY,
  QUICK_ENQUIRY_PHONE,
  COMPANY_ADDRESS_LINES,
  COMPANY_MAP_URL,
} from "@/lib/contact";

const contactSchema = z.object({
  name: z.string().trim().min(2, "Name is required").max(100, "Name is too long"),
  company: z.string().trim().min(2, "Company is required").max(150, "Company name is too long"),
  email: z.string().trim().email("Valid email is required").max(180, "Email is too long"),
  phone: z.string().trim().min(7, "Phone number is required").max(30, "Phone number is too long"),
  country: z.string().trim().min(2, "Country is required").max(100, "Country is too long"),
  subject: z.string().trim().min(2, "Subject is required").max(150, "Subject is too long"),
  quantity: z.string().trim().max(100, "Quantity is too long").optional(),
  message: z.string().trim().min(20, "Please provide at least 20 characters").max(3000, "Message is too long"),
});

type ContactFormValues = z.infer<typeof contactSchema>;

export default function Contact() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const enquiryType = params.get("type");
  const isEnquiry = enquiryType === "enquiry" || enquiryType === "catalogue";
  const defaultSubject = params.get("subject") || (enquiryType === "catalogue" ? "Product Catalogue Request" : "");
  const source = params.get("source") === "product_detail" ? "product_detail" : "contact_page";
  const productSlug = source === "product_detail" ? safeAnalyticsSlug(params.get("product")) : null;
  
  const { toast } = useToast();
  const idempotencyKey = useRef(crypto.randomUUID());
  const submitting = useRef(false);
  const [submitStatus, setSubmitStatus] = useState("");
  const [submitLocked, setSubmitLocked] = useState(false);
  const [receiptId, setReceiptId] = useState<string | null>(null);
  const createEnquiry = useCreateEnquiry({
    request: { headers: { "Idempotency-Key": idempotencyKey.current } },
  });

  const { register, handleSubmit, formState: { errors }, reset } = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      subject: defaultSubject
    }
  });

  const onSubmit = (data: ContactFormValues) => {
    if (submitting.current) return;
    submitting.current = true;
    setSubmitLocked(true);
    setSubmitStatus("Submitting your enquiry.");
    createEnquiry.mutate(
      { data: { ...data, quantity: data.quantity || "N/A" } },
      {
        onSuccess: (res) => {
          trackEvent("enquiry_submitted", {
            enquiry_type: enquiryType === "catalogue" ? "catalogue" : isEnquiry ? "product" : "general",
            source,
            ...(productSlug ? { product_slug: productSlug } : {}),
          });
          toast({
            title: "Enquiry Submitted",
            description: `Reference ID: ${res.enquiryId}. Our team will contact you shortly.`,
          });
          reset();
          idempotencyKey.current = crypto.randomUUID();
          setReceiptId(res.enquiryId);
          setSubmitStatus(`Enquiry submitted successfully. Reference ID ${res.enquiryId}.`);
          window.setTimeout(() => {
            submitting.current = false;
            setSubmitLocked(false);
          }, 1200);
        },
        onError: () => {
          toast({
            title: "Submission Failed",
            description: "There was an error submitting your enquiry. Please try again.",
            variant: "destructive"
          });
          setSubmitStatus("Submission failed. Please check your connection and try again.");
          submitting.current = false;
          setSubmitLocked(false);
        }
      }
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      {/* Hero Section */}
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">GET IN TOUCH</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            {isEnquiry ? "Submit an Enquiry" : "Contact Us"}
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-[#17202A]/80 font-medium leading-relaxed">
            Whether you're looking to source premium Indian products or need assistance with your global trade requirements, our dedicated team is ready to help.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col lg:flex-row gap-12 xl:gap-16">
            
            {/* Contact Info Sidebar */}
            <div className="w-full lg:w-1/3 space-y-8">
              <div className="bg-white p-8 border border-gray-200 shadow-sm border-t-4 border-t-[#062E66]">
                <h3 className="font-bold text-sm uppercase tracking-wider text-[#062E66] mb-6">Corporate Headquarters</h3>
                <ul className="space-y-6 text-sm">
                  <li className="flex gap-4">
                    <div className="w-10 h-10 rounded bg-[#EEF5FC] flex items-center justify-center shrink-0 text-[#062E66]">
                      <MapPin className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="block font-bold text-[#17202A] mb-1">Address</span>
                       <a
                         href={COMPANY_MAP_URL}
                         target="_blank"
                         rel="noopener noreferrer"
                         className="text-gray-600 leading-relaxed block hover:text-[#0A4EA9] transition-colors"
                         dir="ltr"
                       >
                         {COMPANY_ADDRESS_LINES.map((line) => <span key={line} className="block">{line}</span>)}
                         <span className="mt-2 block text-[10px] font-bold uppercase tracking-widest text-[#062E66]">Open in Maps ↗</span>
                       </a>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <div className="w-10 h-10 rounded bg-[#EEF5FC] flex items-center justify-center shrink-0 text-[#062E66]">
                      <Phone className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="block font-bold text-[#17202A] mb-1">Phone</span>
                      <a dir="ltr" href={`tel:${QUICK_ENQUIRY_PHONE}`} className="text-gray-600 hover:text-[#0A4EA9] block">{QUICK_ENQUIRY_PHONE_DISPLAY}</a>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <div className="w-10 h-10 rounded bg-[#EEF5FC] flex items-center justify-center shrink-0 text-[#062E66]">
                      <Mail className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="block font-bold text-[#17202A] mb-1">Email</span>
                      <a dir="ltr" href="mailto:info@preezaglobal.com" className="text-gray-600 hover:text-[#0A4EA9] block">info@preezaglobal.com</a>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <div className="w-10 h-10 rounded bg-[#EEF5FC] flex items-center justify-center shrink-0 text-[#062E66]">
                      <Clock className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="block font-bold text-[#17202A] mb-1">Business Hours</span>
                      <span className="text-gray-600 block">Mon - Fri: 9:00 AM - 6:00 PM (IST)</span>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-[#062E66] p-8 text-white">
                <h3 className="font-bold text-sm uppercase tracking-wider text-[#F2B51D] mb-4">Quick Enquiry</h3>
                <p className="text-xs text-blue-100 mb-6 leading-relaxed">For immediate assistance or quick queries, choose WhatsApp or call our sales team directly.</p>
                <QuickEnquiryDialog className="w-full h-12 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-none font-bold uppercase tracking-wider text-xs">
                  Connect with us
                </QuickEnquiryDialog>
              </div>
            </div>

            {/* Form Area */}
            <div className="w-full lg:w-2/3">
              <div className="bg-white p-8 md:p-12 border border-gray-200 shadow-sm border-t-4 border-t-[#F2B51D]">
                <h2 className="font-serif text-2xl text-[#062E66] font-bold mb-2 uppercase">Send a Message</h2>
                <p className="text-sm text-gray-500 mb-8 pb-6 border-b border-gray-100">Fill out the form below and a representative will get back to you within 24 hours.</p>
                
                {receiptId ? (
                  <div className="border border-green-200 bg-green-50 p-8 text-center" role="status" aria-live="polite">
                    <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-green-700 text-white" aria-hidden="true">✓</div>
                    <h3 className="font-serif text-2xl font-bold text-[#062E66]">Enquiry Received</h3>
                    <p className="mt-3 text-sm text-gray-700">Your reference ID is <strong>{receiptId}</strong>. Our trade team will contact you shortly.</p>
                    <Button
                      type="button"
                      variant="outline"
                      className="mt-6 h-12 rounded-none border-[#062E66] px-8 text-xs font-bold uppercase tracking-widest text-[#062E66]"
                      onClick={() => {
                        setReceiptId(null);
                        setSubmitStatus("");
                        submitting.current = false;
                        setSubmitLocked(false);
                      }}
                    >
                      Submit another enquiry
                    </Button>
                  </div>
                ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
                  <p className="sr-only" role="status" aria-live="polite">{submitStatus}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="contact-name" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center gap-2"><User className="w-3 h-3"/> Full Name *</label>
                      <Input id="contact-name" autoComplete="name" maxLength={100} aria-invalid={!!errors.name} aria-describedby={errors.name ? "contact-name-error" : undefined} {...register("name")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.name ? "border-red-500" : ""}`} />
                      {errors.name && <span id="contact-name-error" className="text-[10px] text-red-500 uppercase">{errors.name.message}</span>}
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="contact-company" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center gap-2"><Building className="w-3 h-3"/> Company Name *</label>
                      <Input id="contact-company" autoComplete="organization" maxLength={150} aria-invalid={!!errors.company} aria-describedby={errors.company ? "contact-company-error" : undefined} {...register("company")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.company ? "border-red-500" : ""}`} />
                      {errors.company && <span id="contact-company-error" className="text-[10px] text-red-500 uppercase">{errors.company.message}</span>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="contact-email" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center gap-2"><Mail className="w-3 h-3"/> Email Address *</label>
                      <Input id="contact-email" type="email" autoComplete="email" maxLength={180} aria-invalid={!!errors.email} aria-describedby={errors.email ? "contact-email-error" : undefined} {...register("email")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.email ? "border-red-500" : ""}`} />
                      {errors.email && <span id="contact-email-error" className="text-[10px] text-red-500 uppercase">{errors.email.message}</span>}
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="contact-phone" className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center gap-2"><Phone className="w-3 h-3"/> Phone Number *</label>
                      <Input id="contact-phone" type="tel" autoComplete="tel" maxLength={30} aria-invalid={!!errors.phone} aria-describedby={errors.phone ? "contact-phone-error" : undefined} {...register("phone")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.phone ? "border-red-500" : ""}`} />
                      {errors.phone && <span id="contact-phone-error" className="text-[10px] text-red-500 uppercase">{errors.phone.message}</span>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="contact-country" className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Country *</label>
                      <Input id="contact-country" autoComplete="country-name" maxLength={100} aria-invalid={!!errors.country} aria-describedby={errors.country ? "contact-country-error" : undefined} {...register("country")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.country ? "border-red-500" : ""}`} />
                      {errors.country && <span id="contact-country-error" className="text-[10px] text-red-500 uppercase">{errors.country.message}</span>}
                    </div>
                    {isEnquiry && (
                      <div className="space-y-2">
                        <label htmlFor="contact-quantity" className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Estimated Quantity</label>
                        <Input id="contact-quantity" maxLength={100} {...register("quantity")} placeholder="e.g., 500 MT, 10 FCL" className="bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66]" />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="contact-subject" className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Subject / Product of Interest *</label>
                    <Input id="contact-subject" maxLength={150} aria-invalid={!!errors.subject} aria-describedby={errors.subject ? "contact-subject-error" : undefined} {...register("subject")} className={`bg-[#F8F8F5] border-gray-200 h-12 rounded-none focus-visible:ring-[#062E66] ${errors.subject ? "border-red-500" : ""}`} />
                    {errors.subject && <span id="contact-subject-error" className="text-[10px] text-red-500 uppercase">{errors.subject.message}</span>}
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="contact-message" className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Message / Requirements *</label>
                    <Textarea id="contact-message" maxLength={3000} aria-invalid={!!errors.message} aria-describedby={errors.message ? "contact-message-error" : undefined} {...register("message")} className={`bg-[#F8F8F5] border-gray-200 min-h-[150px] rounded-none focus-visible:ring-[#062E66] ${errors.message ? "border-red-500" : ""}`} />
                    {errors.message && <span id="contact-message-error" className="text-[10px] text-red-500 uppercase">{errors.message.message}</span>}
                  </div>

                  <div className="pt-4">
                    <Button type="submit" size="lg" className="h-14 px-10 tracking-widest uppercase font-bold text-xs bg-[#062E66] hover:bg-[#0A4EA9] text-white rounded-none group" disabled={createEnquiry.isPending || submitLocked}>
                      {createEnquiry.isPending ? "Submitting..." : "Submit Enquiry"} <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
