import { Link } from "wouter";
import { ArrowRight, FileCheck, Globe2, Leaf, MessageCircle, Search, ShieldCheck, Ship, Users } from "lucide-react";
import { Seo } from "@/components/seo";
import { Reveal } from "@/components/ui/reveal";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";
import { trackEvent } from "@/lib/analytics";
import { QUICK_ENQUIRY_WHATSAPP } from "@/lib/contact";

const categories = [
  { title: "Food Ingredients & Nutraceuticals", short: "Pure ingredients. Global possibilities.", image: siteImages.foodBanner, href: "/products/food-ingredients", tone: "bg-[#e8f0e1]" },
  { title: "Jewellery Collections", short: "Crafted to shine. Designed to inspire.", image: siteImages.brassProducts, href: "/products/jewellery", tone: "bg-[#e8e8f0]" },
  { title: "Handicrafts & Home Décor", short: "Crafted in India. Cherished worldwide.", image: siteImages.potteryImage, href: "/products/handicrafts", tone: "bg-[#f2eadb]" },
  { title: "Indian Heritage Collections", short: "Traditions woven for the world.", image: siteImages.artisansCollage, href: "/products/heritage", tone: "bg-[#eee4e5]" },
];

const markets = [
  { name: "UAE", flag: "🇦🇪", label: "United Arab Emirates" },
  { name: "Saudi Arabia", flag: "🇸🇦", label: "Saudi Arabia" },
  { name: "Oman", flag: "🇴🇲", label: "Oman" },
  { name: "Qatar", flag: "🇶🇦", label: "Qatar" },
  { name: "Singapore", flag: "🇸🇬", label: "Singapore" },
  { name: "Africa", flag: "🌍", label: "Africa region" },
  { name: "Europe", flag: "🇪🇺", label: "European Union" },
];
const proofPoints = [
  { value: "30+", label: "Years combined experience", icon: Users },
  { value: "01", label: "Quality & compliance focus", icon: ShieldCheck },
  { value: "24/7", label: "Responsible trade mindset", icon: Leaf },
  { value: "06", label: "Supplier qualification steps", icon: Search },
];
const processSteps = [
  { number: "01", label: "Market research", icon: Search },
  { number: "02", label: "Supplier assessment", icon: Users },
  { number: "03", label: "Quality verification", icon: ShieldCheck },
  { number: "04", label: "Compliance review", icon: FileCheck },
  { number: "05", label: "Export support", icon: Ship },
];

export default function Home() {
  return (
    <div className="bg-[#f8f7f3] text-primary">
      <Seo title="Home" description="Preeza Global Exim Solutions connects Indian quality products to global markets." schema={{ "@context": "https://schema.org", "@type": "Organization", name: "Preeza Global Exim Solutions", url: "https://preezaglobal.com" }} />

      <section className="relative overflow-hidden bg-primary">
        <ImageWithFallback src={siteImages.heroBanner} alt="" aria-hidden="true" loading="eager" fetchPriority="high" className="absolute inset-[-8px] h-[calc(100%+16px)] w-[calc(100%+16px)] scale-[1.02] object-cover object-center opacity-60 blur-[2px]" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-primary/80 via-primary/60 to-primary/25" aria-hidden="true" />
        <div className="container relative z-10 mx-auto grid min-h-[590px] items-center gap-8 px-4 py-12 md:px-8 lg:grid-cols-[.9fr_1.1fr] lg:py-14">
          <div className="relative z-10 max-w-xl text-white">
            <p className="eyebrow mb-5">India, responsibly connected</p>
            <h1 className="display-title text-5xl leading-[.95] text-white sm:text-6xl lg:text-[4.8rem]">
              Connecting Indian quality products <em className="not-italic text-accent">to global markets.</em>
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-white/85">Your trusted partner for reliable sourcing, quality assurance and seamless export solutions from India.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/products" className="inline-flex h-12 items-center justify-center rounded-sm bg-accent px-6 text-xs font-bold uppercase tracking-[.14em] text-primary transition-colors hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                Explore products <ArrowRight className="ml-3 h-4 w-4" aria-hidden="true" />
              </Link>
              <a href={QUICK_ENQUIRY_WHATSAPP} target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("whatsapp_cta_clicked", { location: "home_hero" })} className="inline-flex h-12 items-center justify-center rounded-sm border border-white/70 px-6 text-xs font-bold uppercase tracking-[.14em] text-white transition-colors hover:bg-white hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                <MessageCircle className="mr-2 h-4 w-4 text-[#209a68]" aria-hidden="true" /> Chat on WhatsApp
              </a>
            </div>
            <div className="mt-10 border-t border-white/25 pt-5">
              <p className="mb-4 text-[10px] font-bold uppercase tracking-[.18em] text-white">Our major export markets</p>
              <div className="flex flex-wrap gap-x-5 gap-y-3">
                {markets.map((market) => (
                  <span key={market.name} className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-wide text-white/80">
                    <span className="text-base leading-none" role="img" aria-label={market.label}>{market.flag}</span>
                    {market.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="relative min-h-[360px] lg:min-h-[490px]">
            <div className="absolute bottom-0 left-0 grid w-[72%] grid-cols-2 gap-2">
              <ImageWithFallback src={siteImages.foodBanner} alt="Indian food ingredients and fruit powders" loading="lazy" className="h-32 w-full rounded-sm object-cover shadow-lg sm:h-40" />
              <ImageWithFallback src={siteImages.brassProducts} alt="Indian brass handicrafts and décor" loading="lazy" className="h-32 w-full rounded-sm object-cover shadow-lg sm:h-40" />
            </div>
            <div className="absolute bottom-[27%] left-[44%] hidden items-center gap-3 rounded-sm bg-white/95 px-4 py-3 text-[10px] font-bold uppercase tracking-wider text-primary shadow-lg sm:flex">
              <Globe2 className="h-5 w-5 text-accent" aria-hidden="true" /> Built for long-term trade
            </div>
          </div>
        </div>
      </section>

      <section className="bg-primary text-white">
        <div className="container mx-auto grid gap-0 px-4 md:grid-cols-[170px_1fr] md:px-8">
          <div className="flex items-center border-b border-white/15 py-5 md:border-b-0 md:border-r"><span className="text-xs font-bold uppercase tracking-[.16em]">Why choose us?</span></div>
          <div className="grid grid-cols-2 divide-x divide-white/15 md:grid-cols-4">
            {proofPoints.map(({ value, label, icon: Icon }) => (
              <div key={label} className="flex items-center gap-3 px-4 py-5 sm:px-6"><Icon className="h-7 w-7 shrink-0 text-accent" aria-hidden="true" /><span><strong className="block font-serif text-xl font-normal">{value}</strong><small className="text-[10px] leading-tight text-blue-100/75">{label}</small></span></div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4 md:px-8">
          <Reveal><div className="mb-10 flex items-end justify-between gap-4"><div><p className="eyebrow mb-3">What we bring to the table</p><h2 className="display-title text-4xl text-primary md:text-5xl">Our product categories</h2></div><Link href="/products" className="hidden items-center gap-2 text-[11px] font-bold uppercase tracking-[.14em] text-primary hover:text-accent sm:flex">View all products <ArrowRight className="h-4 w-4" aria-hidden="true" /></Link></div></Reveal>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((category, index) => <Reveal key={category.title} delay={index * 70}><Link href={category.href} className="group block overflow-hidden rounded-sm border border-primary/10 bg-white transition-transform duration-300 hover:-translate-y-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent" data-testid={`card-category-${index}`}>
              <div className={`image-frame h-48 ${category.tone}`}><ImageWithFallback src={category.image} alt={category.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" /></div>
              <div className="p-5"><h3 className="min-h-12 text-sm font-bold uppercase leading-tight tracking-wide text-primary">{category.title}</h3><p className="mt-2 text-xs italic text-primary/55">{category.short}</p><span className="mt-5 flex h-8 w-8 items-center justify-center rounded-full border border-primary/20 transition-colors group-hover:bg-primary group-hover:text-accent"><ArrowRight className="h-4 w-4" aria-hidden="true" /></span></div>
            </Link></Reveal>)}
          </div>
        </div>
      </section>

      <section className="border-y border-primary/10 bg-white py-14">
        <div className="container mx-auto px-4 md:px-8">
          <div className="mb-9 flex items-center gap-5"><p className="eyebrow whitespace-nowrap">How we work</p><div className="h-px flex-1 bg-primary/10" /></div>
          <div className="grid gap-6 md:grid-cols-5">
            {processSteps.map(({ number, label, icon: Icon }, index) => <div key={label} className="relative flex items-center gap-3 md:block md:text-center"><div className="mx-0 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-accent/60 bg-[#fbfaf7] text-primary md:mx-auto"><Icon className="h-5 w-5" aria-hidden="true" /></div><div><p className="mt-3 text-[10px] font-bold uppercase tracking-[.11em] text-primary">{label}</p><span className="text-[10px] text-accent">{number}</span></div>{index < 4 && <ArrowRight className="absolute right-0 hidden text-accent md:block" aria-hidden="true" />}</div>)}
          </div>
        </div>
      </section>

      <section className="bg-[#edf2f6] py-12">
        <div className="container mx-auto flex flex-col items-center justify-between gap-8 px-4 md:flex-row md:px-8">
          <div><p className="eyebrow mb-2">Ready when you are</p><h2 className="display-title text-3xl text-primary">Let's build a dependable supply line.</h2></div>
          <Link href="/contact" className="inline-flex h-12 items-center rounded-sm bg-accent px-6 text-xs font-bold uppercase tracking-[.14em] text-primary hover:bg-[#d59a2c] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">Start a conversation <ArrowRight className="ml-3 h-4 w-4" aria-hidden="true" /></Link>
        </div>
      </section>
    </div>
  );
}