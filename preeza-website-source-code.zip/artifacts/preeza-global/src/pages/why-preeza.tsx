import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck, Search, Users, Handshake, Ship, HeartHandshake } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

export default function WhyPreeza() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="relative overflow-hidden bg-[#062E66] py-16 lg:py-20 border-b border-gray-200">
        <ImageWithFallback src={siteImages.potteryImage} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 bg-[#062E66]/65" aria-hidden="true" />
        <div className="container relative z-10 mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">THE PREEZA ADVANTAGE</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white font-bold leading-tight mb-6 uppercase">
            Why Preeza?
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-white/85 font-medium leading-relaxed">
            We don't just export products; we build transparent, reliable supply chains that give global buyers absolute peace of mind.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 border border-gray-200 shadow-sm">
              <Users className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">30+ Years Experience</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                Our leadership team brings over three decades of combined international trade experience across the UK, Europe, and Asia Pacific markets.
              </p>
            </div>
            
            <div className="bg-white p-8 border border-gray-200 shadow-sm">
              <Search className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Curated Suppliers</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                We work exclusively with manufacturers who pass our rigorous capability, capacity, and compliance assessments.
              </p>
            </div>

            <div className="bg-white p-8 border border-gray-200 shadow-sm">
              <ShieldCheck className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Zero Compromise</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                Quality is our core metric. We ensure every shipment matches the agreed specifications and international standards.
              </p>
            </div>

            <div className="bg-white p-8 border border-gray-200 shadow-sm">
              <HeartHandshake className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Transparent Operations</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                Honesty in pricing, clear communication regarding lead times, and proactive updates throughout the sourcing process.
              </p>
            </div>

            <div className="bg-white p-8 border border-gray-200 shadow-sm">
              <Ship className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">End-to-End Support</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                From initial sampling and factory negotiation to customs documentation and freight management, we handle it all.
              </p>
            </div>

            <div className="bg-[#062E66] p-8 border border-[#062E66] shadow-sm text-white flex flex-col justify-center items-center text-center">
              <Handshake className="w-12 h-12 text-[#F2B51D] mb-6" />
              <h3 className="font-serif text-2xl font-bold text-white mb-4 uppercase">Long-Term Value</h3>
              <p className="text-sm text-blue-100 leading-relaxed mb-6">
                We seek to build enduring partnerships, not one-time transactions.
              </p>
              <Link href="/contact">
                <Button className="w-full bg-[#F2B51D] hover:bg-[#d69f17] text-[#062E66] font-bold text-xs uppercase tracking-widest rounded-none">
                  Partner With Us
                </Button>
              </Link>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}