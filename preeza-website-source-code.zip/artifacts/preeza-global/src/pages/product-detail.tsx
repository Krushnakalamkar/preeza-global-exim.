import { useRoute, Link } from "wouter";
import { getGetProductQueryKey, useGetProduct } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, CheckCircle2, Globe, Shield, Download, 
  ArrowRight, Users, CheckSquare, ShieldCheck, Ship, FileCheck, Search,
  Leaf
} from "lucide-react";
import { Seo } from "@/components/seo";
import { Reveal } from "@/components/ui/reveal";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";
import { safeAnalyticsSlug, trackEvent } from "@/lib/analytics";
import { useI18n } from "@/lib/i18n";

export default function ProductDetail() {
  const [, params] = useRoute("/products/:slug");
  const slug = params?.slug || "";
  const analyticsSlug = safeAnalyticsSlug(slug) || "unknown";
  const { locale, localizedPath } = useI18n();

  const { data: product, isLoading, isError } = useGetProduct(slug, {
    query: { enabled: !!slug, queryKey: [...getGetProductQueryKey(slug), locale] },
    request: { headers: { "Accept-Language": locale } },
  });
  const catalogueImages: Record<string, string> = {
    "food-ingredients": siteImages.foodBanner,
    jewellery: siteImages.brassProducts,
    handicrafts: siteImages.potteryImage,
    heritage: siteImages.artisansCollage,
  };
const foodCategories = [
  { title: "Fruit powders", items: ["Banana powder", "Pomegranate powder", "Mango powder", "Guava powder"], tone: "bg-[#f2eadb]", position: "object-[50%_58%]" },
  { title: "Vegetable powders", items: ["Onion powder", "Garlic powder", "Beetroot powder", "Tomato powder"], tone: "bg-[#eee4e5]", position: "object-[66%_46%]" },
  { title: "Spice ingredients", items: ["Turmeric powder", "Chilli powder", "Cumin powder", "Coriander powder"], tone: "bg-[#f4e2ca]", position: "object-[42%_52%]" },
  { title: "Nutraceutical ingredients", items: ["Functional ingredients", "Wellness powders", "Plant-based extracts", "Herbal ingredients"], tone: "bg-[#e8f0e1]", position: "object-[58%_42%]" },
];
const featuredFoodProducts = [
  { title: "Turmeric powder", spec: "Curcumin: 2–6%", position: "object-[28%_58%]" },
  { title: "Onion powder", spec: "Moisture: < 8%", position: "object-[68%_50%]" },
  { title: "Banana powder", spec: "Solubility: 95%", position: "object-[44%_66%]" },
  { title: "Pomegranate powder", spec: "Moisture: < 6%", position: "object-[80%_40%]" },
  { title: "Cumin powder", spec: "Purity: 99%", position: "object-[18%_36%]" },
];

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-24 flex justify-center bg-[#F8F8F5]">
        <div className="animate-pulse flex flex-col items-center w-full max-w-4xl px-4">
          <div className="h-8 w-64 bg-gray-200 mb-8 rounded"></div>
          <div className="h-96 w-full bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (isError || !product) {
    return (
      <div className="min-h-screen pt-32 pb-24 container mx-auto px-4 text-center bg-[#F8F8F5]">
        <h2 className="text-2xl font-serif font-bold text-[#062E66] mb-4">Product Not Found</h2>
        <Link href={localizedPath("/products")}>
          <Button variant="outline" className="border-[#062E66] text-[#062E66]">Return to Products</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5] overflow-x-clip">
      <Seo 
        title={product.name} 
        description={product.description}
        image={product.imageUrl}
        schema={{
          "@context": "https://schema.org/",
          "@type": "Product",
          "name": product.name,
          "image": product.imageUrl ? [product.imageUrl] : [],
          "description": product.description,
          "brand": {
            "@type": "Brand",
            "name": "Preeza Global Exim Solutions"
          }
        }}
      />
      {/* Breadcrumb */}
      <div className="border-b border-gray-200 bg-white">
        <div className="container mx-auto px-4 md:px-8 py-3 flex items-center text-[10px] uppercase font-bold tracking-widest text-gray-500">
          <Link href="/" className="hover:text-[#062E66] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary rounded-sm p-1">Home</Link>
          <span className="mx-2" aria-hidden="true">›</span>
          <Link href="/products" className="hover:text-[#062E66] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary rounded-sm p-1">Products</Link>
          <span className="mx-2" aria-hidden="true">›</span>
          <span className="text-[#062E66] p-1">{product.category}</span>
          <span className="mx-2" aria-hidden="true">›</span>
          <span className="text-[#062E66] p-1" aria-current="page">{product.name}</span>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-white py-12 lg:py-16 border-b border-gray-200">
        <Reveal>
          <div className="container mx-auto px-4 md:px-8">
            <div className="flex flex-col lg:flex-row gap-12 items-start">
              
              {/* Left Content */}
              <div className="w-full lg:w-1/2">
                <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#062E66] font-bold leading-tight mb-4 uppercase">
                  {product.name}
                </h1>
                <h2 className="text-[#F2B51D] font-bold text-lg md:text-xl mb-6 font-serif uppercase tracking-wide">
                  Solutions For Global Markets
                </h2>
                <p className="text-[#17202A]/80 leading-relaxed mb-8 text-sm max-w-lg font-medium">
                  {product.description}
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link
                    href={`/contact?type=catalogue&source=product_detail&product=${encodeURIComponent(slug)}&subject=Catalogue for ${encodeURIComponent(product.name)}`}
                    onClick={() => trackEvent("catalogue_requested", {
                      product_slug: analyticsSlug,
                    })}
                  >
                    <Button className="w-full sm:w-auto h-12 px-8 text-xs font-bold tracking-widest uppercase bg-[#062E66] hover:bg-[#0A4EA9] text-white rounded-none group">
                      REQUEST CATALOGUE <Download className="h-4 w-4 ml-2 group-hover:-translate-y-1 transition-transform" aria-hidden="true" />
                    </Button>
                  </Link>
                  <Link
                    href={`/contact?type=enquiry&source=product_detail&product=${encodeURIComponent(slug)}&subject=Enquiry for ${encodeURIComponent(product.name)}`}
                    onClick={() => trackEvent("product_enquiry_started", {
                      product_slug: analyticsSlug,
                    })}
                  >
                    <Button variant="outline" className="w-full sm:w-auto h-12 px-8 text-xs font-bold tracking-widest uppercase border-gray-300 text-[#062E66] hover:bg-gray-50 rounded-none group">
                      CONTACT OUR TEAM <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
                    </Button>
                  </Link>
                </div>
              </div>

              {/* Right Details/Image */}
              <div className="w-full lg:w-1/2 flex flex-col sm:flex-row items-center gap-8 relative">
                <div className="w-full sm:w-2/3 h-64 md:h-80 overflow-hidden border border-gray-100 shadow-sm block">
                  <ImageWithFallback 
                    src={catalogueImages[slug] || product.imageUrl || siteImages.foodBanner}
                    alt={product.name} 
                    fetchPriority="high"
                    loading="eager"
                    className="w-full h-full object-cover" 
                  />
                </div>
                <div className="w-full sm:w-1/3 flex flex-col gap-6 text-xs text-[#062E66] font-medium">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-[#F2B51D] shrink-0" aria-hidden="true" />
                    <span>Quality Assured & Verified Standard</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Globe className="w-5 h-5 text-[#F2B51D] shrink-0" aria-hidden="true" />
                    <span>Global Standards Compliance</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Leaf className="w-5 h-5 text-[#F2B51D] shrink-0" aria-hidden="true" />
                    <span>Sustainable Sourcing</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Ship className="w-5 h-5 text-[#F2B51D] shrink-0" aria-hidden="true" />
                    <span>Export Ready Capabilities</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </Reveal>
      </section>

      {slug === "food-ingredients" && (
        <section className="border-b border-primary/10 bg-[#f8f7f3] py-10 md:py-14">
          <div className="container mx-auto px-4 md:px-8">
            <Reveal>
              <div className="mb-7 flex items-end justify-between gap-5">
                <div>
                  <p className="eyebrow mb-3">The food ingredients catalogue</p>
                  <h2 className="display-title text-4xl text-primary md:text-5xl">From harvest to formulation.</h2>
                </div>
                <Link href="/products" className="hidden items-center gap-2 text-[10px] font-bold uppercase tracking-[.14em] text-primary hover:text-accent sm:flex">
                  View all products <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </div>
            </Reveal>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {foodCategories.map((category, index) => (
                <Reveal key={category.title} delay={index * 60}>
                  <article className={`overflow-hidden rounded-sm border border-primary/10 bg-white ${category.tone}`}>
                    <div className="h-24 overflow-hidden border-b border-primary/10 sm:h-28">
                      <ImageWithFallback src={siteImages.foodBanner} alt={`${category.title} from India`} loading="lazy" className={`h-full w-full object-cover ${category.position}`} />
                    </div>
                    <div className="p-4">
                      <h3 className="text-xs font-bold uppercase leading-tight tracking-wide text-primary">{category.title}</h3>
                      <ul className="mt-3 space-y-1.5">
                        {category.items.map((item) => (
                          <li key={item} className="flex items-start gap-2 text-[10px] leading-tight text-primary/70">
                            <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-[#3f754c]" aria-hidden="true" />
                            {item}
                          </li>
                        ))}
                      </ul>
                      <Link href={`/contact?type=catalogue&source=food_category&subject=${encodeURIComponent(category.title)}`} className="mt-4 inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-[.12em] text-primary hover:text-accent">
                        View products <ArrowRight className="h-3 w-3" aria-hidden="true" />
                      </Link>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>

            <Reveal>
              <div className="mb-5 mt-12 flex items-center gap-4">
                <p className="eyebrow whitespace-nowrap">Featured products</p>
                <div className="h-px flex-1 bg-primary/10" />
              </div>
            </Reveal>
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
              {featuredFoodProducts.map((item, index) => (
                <Reveal key={item.title} delay={index * 55}>
                  <article className="overflow-hidden rounded-sm border border-primary/10 bg-white">
                    <div className="image-frame h-28 bg-[#eee9df]">
                      <ImageWithFallback src={siteImages.foodBanner} alt={item.title} loading="lazy" className={`h-full w-full object-cover ${item.position}`} />
                    </div>
                    <div className="p-4">
                      <h3 className="text-xs font-bold uppercase leading-tight text-primary">{item.title}</h3>
                      <p className="mt-2 text-[10px] text-primary/60">{item.spec}</p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Link href={`/contact?type=enquiry&source=featured_food_product&subject=${encodeURIComponent(`Enquiry for ${item.title}`)}`} className="inline-flex min-h-7 items-center rounded-sm bg-primary px-2.5 text-[9px] font-bold uppercase tracking-wide text-white hover:bg-secondary">
                          Request info
                        </Link>
                        <Link href={`/contact?type=catalogue&source=featured_food_product&subject=${encodeURIComponent(`Spec sheet for ${item.title}`)}`} className="inline-flex min-h-7 items-center rounded-sm border border-primary/20 px-2.5 text-[9px] font-bold uppercase tracking-wide text-primary hover:border-accent hover:text-accent">
                          Spec sheet
                        </Link>
                      </div>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Specifications & Details */}
      <section className="py-12 bg-[#F8F8F5]">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid min-w-0 grid-cols-1 md:grid-cols-2 gap-12 bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
            
            <div className="min-w-0">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#F2B51D] mb-6 border-b border-gray-100 pb-2">Key Specifications</h3>
              <ul className="space-y-4 text-sm text-gray-700">
                {product.specifications.map((spec, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-[#062E66] shrink-0 mt-0.5" />
                    <span>{spec}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3">Origin</h4>
                <p className="text-sm font-medium text-[#062E66] flex items-center gap-2"><Globe className="w-4 h-4 text-[#F2B51D]"/> {product.origin}</p>
              </div>
            </div>

            <div className="min-w-0">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#F2B51D] mb-6 border-b border-gray-100 pb-2">Export Parameters</h3>
              
              <div className="mb-6">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3">Target Markets</h4>
                <div className="flex flex-wrap gap-2">
                  {product.markets.map((market, i) => (
                    <span key={i} className="px-3 py-1 bg-[#EEF5FC] text-[#062E66] text-xs font-bold uppercase tracking-wider border border-blue-100">
                      {market}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3">Quality Standards</h4>
                <div className="bg-[#062E66] text-white p-4 text-sm flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-[#F2B51D] shrink-0" />
                  <p>{product.quality}</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Process & Why Choose Us Bottom Section (Reused from Products for consistency) */}
      <section className="py-16 bg-[#EEF5FC] border-t-2 border-[#062E66]">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-12">
            
            {/* Selection Process */}
            <div>
              <h3 className="font-bold uppercase tracking-widest text-sm text-[#062E66] mb-8 break-words">OUR PRODUCT QUALIFICATION PROCESS</h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 relative">
                <div className="hidden sm:block absolute top-6 left-12 right-12 h-[1px] bg-blue-200 z-0"></div>
                {[
                  { num: 1, title: "Supplier Review", icon: Users },
                  { num: 2, title: "Capability Assessment", icon: CheckSquare },
                  { num: 3, title: "Product Evaluation", icon: Search },
                  { num: 4, title: "Quality Verification", icon: ShieldCheck },
                  { num: 5, title: "Export Readiness", icon: Ship },
                ].map((step, i) => (
                  <div key={i} className="flex flex-col items-center relative z-10 text-center">
                    <div className="w-12 h-12 rounded-full bg-white border border-blue-200 flex items-center justify-center text-[#062E66] mb-3 relative shadow-sm">
                      <step.icon className="w-5 h-5" />
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#F2B51D] text-[#062E66] flex items-center justify-center text-[8px] font-bold">
                        {step.num}
                      </div>
                    </div>
                    <span className="text-[9px] font-bold uppercase text-[#062E66] leading-tight">{step.title}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Why Source Through Preeza */}
            <div>
              <h3 className="font-bold uppercase tracking-widest text-sm text-[#062E66] mb-8">WHY SOURCE THROUGH PREEZA?</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { title: "Qualified Suppliers", icon: ShieldCheck, desc: "Carefully evaluated manufacturers." },
                  { title: "Quality Verification", icon: CheckCircle2, desc: "Multi-level quality checks." },
                  { title: "Compliance Focus", icon: FileCheck, desc: "Adherence to global food safety." },
                  { title: "Export Support", icon: Ship, desc: "End-to-end documentation support." },
                ].map((item, i) => (
                  <div key={i} className="bg-white p-4 border border-gray-100 text-center flex flex-col items-center shadow-sm">
                    <item.icon className="w-6 h-6 text-[#062E66] mb-3" />
                    <span className="text-[10px] font-bold uppercase text-[#062E66] mb-2 leading-tight">{item.title}</span>
                    <span className="text-[9px] text-gray-500 leading-tight">{item.desc}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
}