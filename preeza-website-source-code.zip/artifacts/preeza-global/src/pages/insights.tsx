import { Link } from "wouter";
import { useListNews } from "@workspace/api-client-react";
import { Calendar, ArrowRight, Newspaper } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";
import { useI18n } from "@/lib/i18n";

export default function Insights() {
  const { locale } = useI18n();
  const { data: articles, isLoading } = useListNews({ lang: locale });

  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="relative overflow-hidden bg-[#062E66] py-16 lg:py-20 border-b border-gray-200">
        <ImageWithFallback src={siteImages.heroBanner} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-[#062E66]/70" aria-hidden="true" />
        <div className="container relative z-10 mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">NEWS & UPDATES</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white font-bold leading-tight mb-6 uppercase">
            Market Insights
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-white/85 font-medium leading-relaxed">
            Institutional perspectives on global trade dynamics, market volatility, and supply chain strategies.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-96 border border-gray-200 animate-pulse bg-white"></div>
              ))}
            </div>
          ) : !articles || articles.length === 0 ? (
            <div className="text-center py-32 border border-dashed border-gray-300 bg-white">
              <Newspaper className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="font-serif text-2xl font-bold text-[#062E66] mb-2">No Insights Published</h3>
              <p className="text-gray-500 text-sm">Check back later for market updates and reports.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {articles.map((article) => (
                <Link key={article.id} href={`/insights/${article.slug}`} className="group border border-gray-200 bg-white overflow-hidden flex flex-col hover:border-[#062E66] hover:shadow-xl transition-all">
                  <div className="h-56 bg-gray-100 relative overflow-hidden border-b border-gray-200">
                    {article.imageUrl ? (
                      <img src={article.imageUrl} alt={article.title} className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-700" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-300">
                        <Newspaper className="h-12 w-12" />
                      </div>
                    )}
                    {article.featured && (
                      <div className="absolute top-4 left-4">
                        <span className="bg-[#F2B51D] text-[#062E66] text-[10px] font-bold uppercase tracking-widest px-3 py-1 shadow-sm">
                          Featured Report
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="p-8 flex flex-col flex-1">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-4 border-b border-gray-100 pb-4">
                      <Calendar className="h-3 w-3" />
                      {new Date(article.publishedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                    <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 group-hover:text-[#0A4EA9] transition-colors leading-snug uppercase">{article.title}</h3>
                    <p className="text-gray-500 mb-8 flex-1 leading-relaxed text-sm font-medium">{article.excerpt}</p>
                    <div className="flex items-center text-[10px] font-bold uppercase tracking-widest text-[#062E66] gap-2 mt-auto group-hover:text-[#F2B51D] transition-colors">
                      Read Full Report <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}