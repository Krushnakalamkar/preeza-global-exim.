import { Link } from "wouter";

export default function Privacy() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <h1 className="font-serif text-3xl md:text-4xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            Privacy Policy
          </h1>
          <div className="h-[2px] w-16 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-gray-500 font-medium">Last updated: {new Date().toLocaleDateString()}</p>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 md:px-8 max-w-3xl">
          <div className="bg-white p-8 md:p-12 border border-gray-200 shadow-sm prose prose-blue prose-sm max-w-none text-gray-600">
            <h2 className="text-[#062E66] font-serif uppercase tracking-wide">1. Information We Collect</h2>
            <p>
              We collect information that you provide directly to us when using our services, including contact forms, 
              enquiry submissions, and account registration. This may include your name, company name, email address, 
              phone number, and any other information you choose to provide.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">2. How We Use Your Information</h2>
            <p>
              We use the information we collect to:
            </p>
            <ul>
              <li>Provide, maintain, and improve our services</li>
              <li>Process and respond to your enquiries and requests</li>
              <li>Send you technical notices, updates, and administrative messages</li>
              <li>Communicate with you about products, services, and events</li>
            </ul>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">3. Information Sharing</h2>
            <p>
              We do not share your personal information with third parties except as described in this privacy policy 
              or with your consent. We may share information with vendors, consultants, and other service providers 
              who need access to such information to carry out work on our behalf.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">4. Security</h2>
            <p>
              We take reasonable measures to help protect information about you from loss, theft, misuse, unauthorized 
              access, disclosure, alteration, and destruction.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">5. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at: 
              <br />
              <strong>Email:</strong> privacy@preezaglobal.com
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}