import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Utensils, Diamond, Lamp, Shirt } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

export default function Industries() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">SECTORS WE SERVE</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            Industries We Serve
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-[#17202A]/80 font-medium leading-relaxed">
            Specialized sourcing and export capabilities across four key global sectors.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            
            <div className="bg-white border border-gray-200 shadow-sm flex flex-col sm:flex-row group">
              <div className="relative w-full sm:w-1/3 min-h-44 overflow-hidden bg-[#EEF5FC] border-b sm:border-b-0 sm:border-r border-gray-100">
                <ImageWithFallback src={siteImages.foodBanner} alt="Fruit and spice powders for food and beverage manufacturers" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-[#062E66]/70 to-transparent p-5"><Utensils className="h-9 w-9 text-[#F2B51D]" /></div>
              </div>
              <div className="w-full sm:w-2/3 p-8 flex flex-col justify-center">
                <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Food & Beverage</h3>
                <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                  Supplying food manufacturers, nutraceutical companies, and retail brands with high-quality, pure Indian spices, fruit, and vegetable powders.
                </p>
                <Link href="/products/food-ingredients" className="text-[10px] font-bold uppercase tracking-widest text-[#062E66] flex items-center gap-1 hover:text-[#0A4EA9]">
                  View Capabilities <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>

            <div className="bg-white border border-gray-200 shadow-sm flex flex-col sm:flex-row group">
              <div className="relative w-full sm:w-1/3 min-h-44 overflow-hidden bg-[#EEF5FC] border-b sm:border-b-0 sm:border-r border-gray-100">
                <ImageWithFallback src={siteImages.brassProducts} alt="Metal craft collection for jewellery and luxury retail" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-[#062E66]/70 to-transparent p-5"><Diamond className="h-9 w-9 text-[#F2B51D]" /></div>
              </div>
              <div className="w-full sm:w-2/3 p-8 flex flex-col justify-center">
                <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Jewellery Retail</h3>
                <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                  Partnering with global jewellery boutiques and luxury retailers to source finely crafted lab-grown diamonds and fashion jewellery collections.
                </p>
                <Link href="/products/jewellery" className="text-[10px] font-bold uppercase tracking-widest text-[#062E66] flex items-center gap-1 hover:text-[#0A4EA9]">
                  View Capabilities <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>

            <div className="bg-white border border-gray-200 shadow-sm flex flex-col sm:flex-row group">
              <div className="relative w-full sm:w-1/3 min-h-44 overflow-hidden bg-[#EEF5FC] border-b sm:border-b-0 sm:border-r border-gray-100">
                <ImageWithFallback src={siteImages.potteryImage} alt="Indian pottery and home décor collection" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-[#062E66]/70 to-transparent p-5"><Lamp className="h-9 w-9 text-[#F2B51D]" /></div>
              </div>
              <div className="w-full sm:w-2/3 p-8 flex flex-col justify-center">
                <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Interior Design & Décor</h3>
                <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                  Providing home décor retailers, interior designers, and hospitality projects with authentic Indian brass artefacts and wooden carvings.
                </p>
                <Link href="/products/handicrafts" className="text-[10px] font-bold uppercase tracking-widest text-[#062E66] flex items-center gap-1 hover:text-[#0A4EA9]">
                  View Capabilities <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>

            <div className="bg-white border border-gray-200 shadow-sm flex flex-col sm:flex-row group">
              <div className="relative w-full sm:w-1/3 min-h-44 overflow-hidden bg-[#EEF5FC] border-b sm:border-b-0 sm:border-r border-gray-100">
                <ImageWithFallback src={siteImages.artisansCollage} alt="Indian artisans and heritage textiles" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-[#062E66]/70 to-transparent p-5"><Shirt className="h-9 w-9 text-[#F2B51D]" /></div>
              </div>
              <div className="w-full sm:w-2/3 p-8 flex flex-col justify-center">
                <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Fashion & Textiles</h3>
                <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                  Sourcing premium Indian heritage textiles, including Pashmina shawls and hand-block prints, for global fashion labels and premium apparel retailers.
                </p>
                <Link href="/products/heritage" className="text-[10px] font-bold uppercase tracking-widest text-[#062E66] flex items-center gap-1 hover:text-[#0A4EA9]">
                  View Capabilities <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}