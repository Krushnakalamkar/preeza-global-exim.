import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe2 } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

const marketHubs = [
  { code: "UAE", name: "United Arab Emirates", flag: "🇦🇪", status: "Primary Hub" },
  { code: "KSA", name: "Saudi Arabia", flag: "🇸🇦", status: "Growing Market" },
  { code: "OMN", name: "Oman", flag: "🇴🇲", status: "Strategic Partner" },
  { code: "EU", name: "European Union", flag: "🇪🇺", status: "Quality Driven" },
];

const tradeRoutes = [
  {
    flag: "🌍",
    label: "Middle East (GCC)",
    countries: [
      { name: "United Arab Emirates", flag: "🇦🇪" },
      { name: "Saudi Arabia", flag: "🇸🇦" },
      { name: "Oman", flag: "🇴🇲" },
      { name: "Qatar", flag: "🇶🇦" },
      { name: "Bahrain", flag: "🇧🇭" },
    ],
  },
  {
    flag: "🌏",
    label: "South East Asia",
    countries: [
      { name: "Singapore", flag: "🇸🇬" },
      { name: "Malaysia", flag: "🇲🇾" },
      { name: "Vietnam", flag: "🇻🇳" },
      { name: "Indonesia", flag: "🇮🇩" },
    ],
  },
  {
    flag: "🇪🇺",
    label: "Europe & UK",
    countries: [
      { name: "United Kingdom", flag: "🇬🇧" },
      { name: "Germany", flag: "🇩🇪" },
      { name: "France", flag: "🇫🇷" },
      { name: "Netherlands", flag: "🇳🇱" },
    ],
  },
];

export default function GlobalMarkets() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">GLOBAL REACH</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            Our Markets
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-[#17202A]/80 font-medium leading-relaxed">
            Delivering Indian excellence to strategic trade hubs across the Middle East, Europe, and Asia.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col lg:flex-row gap-12 items-center mb-16">
            <div className="w-full lg:w-1/2">
              <div className="aspect-[4/3] bg-[#EEF5FC] border border-blue-100 flex items-center justify-center relative overflow-hidden">
                <ImageWithFallback src={siteImages.heroBanner} alt="Container shipping and global trade routes" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-[#062E66]/55" aria-hidden="true" />
                <Globe2 className="w-64 h-64 text-white/20 absolute" />
                 <div className="grid grid-cols-2 gap-4 relative z-10 w-full p-8">
                    {marketHubs.map((market) => (
                      <div key={market.code} className="bg-white p-4 shadow-sm border border-gray-100 text-center flex flex-col items-center">
                        <span className="mb-2 text-4xl leading-none" role="img" aria-label={market.name}>{market.flag}</span>
                        <span className="font-serif text-3xl text-[#062E66] font-bold mb-1">{market.code}</span>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{market.status}</span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
            
            <div className="w-full lg:w-1/2">
              <h2 className="font-serif text-3xl font-bold text-[#062E66] mb-6 uppercase">Strategic Trade Routes</h2>
              <p className="text-sm text-gray-600 mb-8 leading-relaxed font-medium">
                Our export operations are optimized for key global corridors, ensuring efficient transit times, streamlined customs clearance, and cost-effective logistics for our buyers.
              </p>
              
              <ul className="space-y-4 mb-8">
                {tradeRoutes.map((route) => (
                  <li key={route.label} className="flex items-start gap-3">
                    <span className="mt-0.5 text-2xl leading-none" role="img" aria-label={`${route.label} region`}>{route.flag}</span>
                    <div>
                      <span className="block font-bold text-[#062E66] text-sm uppercase mb-2">{route.label}</span>
                      <div className="flex flex-wrap gap-x-3 gap-y-2">
                        {route.countries.map((country) => (
                          <span key={country.name} className="inline-flex items-center gap-1.5 text-xs text-gray-500">
                            <span className="text-base leading-none" role="img" aria-label={country.name}>{country.flag}</span>
                            {country.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              
              <Link href="/contact">
                <Button variant="outline" className="h-12 px-8 text-xs font-bold tracking-widest uppercase border-[#062E66] text-[#062E66] hover:bg-[#062E66] hover:text-white rounded-none">
                  Check Market Feasibility
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#062E66] py-16 border-t-4 border-[#F2B51D] text-center">
        <div className="container mx-auto px-4">
          <h3 className="font-serif text-3xl font-bold text-white mb-4 uppercase">Looking to Source for Your Region?</h3>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">We understand local compliance, documentation, and market preferences for all our target destinations.</p>
          <Link href="/contact">
            <Button className="h-12 px-10 text-xs font-bold tracking-widest uppercase bg-[#F2B51D] hover:bg-[#d69f17] text-[#062E66] rounded-none group">
              Start Sourcing <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}