import { useGetDashboardSummary } from "@workspace/api-client-react"
import { Package, FileText, MessageSquare, AlertCircle } from "lucide-react"

export default function AdminDashboard() {
  const { data: summary, isLoading, isError } = useGetDashboardSummary()

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="font-serif text-3xl font-bold text-primary">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-32 bg-white border border-border animate-pulse rounded-md"></div>
          ))}
        </div>
      </div>
    )
  }

  if (isError || !summary) {
    return (
      <div className="p-6 bg-destructive/10 text-destructive border border-destructive/20 rounded-md">
        Failed to load dashboard summary.
      </div>
    )
  }

  const cards = [
    { title: "Total Products", value: summary.products, icon: Package, link: "/admin/products" },
    { title: "Published Articles", value: summary.articles, icon: FileText, link: "/admin/content" },
    { title: "Total Enquiries", value: summary.enquiries, icon: MessageSquare, link: "/admin/enquiries" },
    { title: "New Enquiries", value: summary.newEnquiries, icon: AlertCircle, link: "/admin/enquiries", alert: true },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-serif text-3xl font-bold text-primary mb-2">Dashboard Overview</h1>
        <p className="text-muted-foreground">Welcome back. Here's what's happening with your operations today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => {
          const Icon = card.icon
          return (
            <div key={i} className="bg-white border border-border p-6 shadow-sm rounded-md relative overflow-hidden">
              {card.alert && card.value > 0 && (
                <div className="absolute top-0 right-0 w-2 h-full bg-accent"></div>
              )}
              <div className="flex items-center justify-between mb-4">
                <div className="h-10 w-10 bg-muted flex items-center justify-center rounded border border-border">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-3xl font-bold font-serif text-foreground mb-1">{card.value}</h3>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{card.title}</p>
              </div>
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white border border-border rounded-md shadow-sm">
          <div className="p-6 border-b border-border">
            <h3 className="font-serif text-xl font-bold text-primary">System Status</h3>
          </div>
          <div className="p-6">
            <ul className="space-y-4">
              <li className="flex items-center justify-between">
                <span className="text-sm font-medium">API Connection</span>
                <span className="flex items-center gap-2 text-sm text-green-600 font-medium">
                  <span className="h-2 w-2 rounded-full bg-green-600"></span> Online
                </span>
              </li>
              <li className="flex items-center justify-between">
                <span className="text-sm font-medium">Database Sync</span>
                <span className="flex items-center gap-2 text-sm text-green-600 font-medium">
                  <span className="h-2 w-2 rounded-full bg-green-600"></span> Synced
                </span>
              </li>
              <li className="flex items-center justify-between">
                <span className="text-sm font-medium">Last Backup</span>
                <span className="text-sm text-muted-foreground">Today, 04:00 AM</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
