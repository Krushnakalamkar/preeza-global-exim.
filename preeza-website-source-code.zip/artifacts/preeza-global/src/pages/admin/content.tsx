import { useListNews } from "@workspace/api-client-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus, Edit, Eye } from "lucide-react"

export default function AdminContent() {
  const { data: articles, isLoading } = useListNews()

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-serif text-3xl font-bold text-primary mb-2">Content Management</h1>
          <p className="text-muted-foreground">Manage market insights, reports, and company news.</p>
        </div>
        <Button className="gap-2 uppercase tracking-widest text-xs">
          <Plus className="h-4 w-4" /> Publish Insight
        </Button>
      </div>

      <div className="bg-white border border-border rounded-md shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading content...</div>
        ) : !articles || articles.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No content published yet.</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Published Date</TableHead>
                <TableHead>Visibility</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {articles.map((article) => (
                <TableRow key={article.id}>
                  <TableCell className="font-medium max-w-md truncate">{article.title}</TableCell>
                  <TableCell>{new Date(article.publishedAt).toLocaleDateString()}</TableCell>
                  <TableCell>
                    {article.featured ? <Badge variant="accent">Featured</Badge> : <Badge variant="secondary">Public</Badge>}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-primary">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-primary">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  )
}
