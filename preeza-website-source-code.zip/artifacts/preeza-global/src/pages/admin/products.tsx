import { useState } from "react"
import { useListProducts, useDeleteProduct } from "@workspace/api-client-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useQueryClient } from "@tanstack/react-query"
import { getListProductsQueryKey } from "@workspace/api-client-react"
import { useToast } from "@/hooks/use-toast"
import { Plus, Trash2, Edit } from "lucide-react"

export default function AdminProducts() {
  const { data: products, isLoading } = useListProducts()
  const deleteProduct = useDeleteProduct()
  const queryClient = useQueryClient()
  const { toast } = useToast()

  const handleDelete = (slug: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      deleteProduct.mutate(
        { slug },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() })
            toast({ title: "Product deleted" })
          },
          onError: () => {
            toast({ title: "Error deleting product", variant: "destructive" })
          }
        }
      )
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-serif text-3xl font-bold text-primary mb-2">Products Catalog</h1>
          <p className="text-muted-foreground">Manage your global commodity and product listings.</p>
        </div>
        <Button className="gap-2 uppercase tracking-widest text-xs">
          <Plus className="h-4 w-4" /> Add Product
        </Button>
      </div>

      <div className="bg-white border border-border rounded-md shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading products...</div>
        ) : !products || products.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No products found.</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Origin</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell><Badge variant="outline">{product.category}</Badge></TableCell>
                  <TableCell>{product.origin}</TableCell>
                  <TableCell>
                    {product.featured ? <Badge variant="accent">Featured</Badge> : <Badge variant="secondary">Standard</Badge>}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-primary">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => handleDelete(product.slug)}
                      disabled={deleteProduct.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  )
}
