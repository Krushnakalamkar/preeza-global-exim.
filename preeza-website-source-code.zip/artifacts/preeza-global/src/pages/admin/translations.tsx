import { useEffect, useMemo, useState } from "react";
import { Check, Globe2, Languages, Search, Save, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/i18n";

type TranslationEntry = {
  id: number;
  key: string;
  locale: string;
  value: string;
  namespace: string;
  status: "draft" | "published";
};

type AdminLanguage = {
  id: number;
  code: string;
  name: string;
  nativeName: string;
  direction: "ltr" | "rtl";
  enabled: boolean;
  isDefault: boolean;
  sortOrder: number;
};

type ContentItem = { slug: string; name?: string; title?: string };
type ContentTranslation = Record<string, unknown> & { locale: string; status: "draft" | "published" };

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, credentials: "include", headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
  if (!response.ok) throw new Error((await response.json().catch(() => null))?.error || `Request failed (${response.status})`);
  return response.status === 204 ? (undefined as T) : response.json() as Promise<T>;
}

export default function AdminTranslations() {
  const { t, languages } = useI18n();
  const [locale, setLocale] = useState("hi");
  const [query, setQuery] = useState("");
  const [entries, setEntries] = useState<TranslationEntry[]>([]);
  const [adminLanguages, setAdminLanguages] = useState<AdminLanguage[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");
  const [contentType, setContentType] = useState<"products" | "news">("products");
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [contentSlug, setContentSlug] = useState("");
  const [contentLocale, setContentLocale] = useState("hi");
  const [contentTranslation, setContentTranslation] = useState<ContentTranslation | null>(null);
  const [contentLoading, setContentLoading] = useState(false);
  const [contentSaving, setContentSaving] = useState(false);

  const languageOptions = useMemo(() => languages.filter((item) => item.code !== "en").slice(0, 240), [languages]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([
      requestJson<TranslationEntry[]>(`/api/admin/translations?locale=${encodeURIComponent(locale)}&query=${encodeURIComponent(query)}`),
      requestJson<AdminLanguage[]>("/api/admin/languages"),
    ]).then(([nextEntries, nextLanguages]) => {
      if (!active) return;
      setEntries(nextEntries);
      setAdminLanguages(nextLanguages);
    }).catch((error: Error) => {
      if (active) setMessage(error.message);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [locale, query]);

  useEffect(() => {
    Promise.all([
      requestJson<Array<{ slug: string; name: string }>>("/api/products"),
      requestJson<Array<{ slug: string; title: string }>>("/api/news"),
    ]).then(([productRows, newsRows]) => {
      setContentItems(contentType === "products" ? productRows : newsRows);
      setContentSlug((current) => current || (contentType === "products" ? productRows[0]?.slug : newsRows[0]?.slug) || "");
    }).catch(() => setContentItems([]));
  }, [contentType]);

  useEffect(() => {
    if (!contentSlug) return;
    let active = true;
    setContentLoading(true);
    requestJson<ContentTranslation[]>(`/api/admin/${contentType}/${encodeURIComponent(contentSlug)}/translations`)
      .then((rows) => {
        if (!active) return;
        const existing = rows.find((row) => row.locale === contentLocale);
        setContentTranslation(existing || { locale: contentLocale, status: "draft" });
      })
      .catch(() => { if (active) setContentTranslation({ locale: contentLocale, status: "draft" }); })
      .finally(() => { if (active) setContentLoading(false); });
    return () => { active = false; };
  }, [contentLocale, contentSlug, contentType]);

  const updateEntry = (key: string, value: string) => {
    setEntries((current) => current.map((entry) => entry.key === key ? { ...entry, value } : entry));
  };

  const saveEntry = async (entry: TranslationEntry) => {
    setSavingKey(entry.key);
    try {
      const saved = await requestJson<TranslationEntry>(`/api/admin/translations/${encodeURIComponent(locale)}/${encodeURIComponent(entry.key)}`, {
        method: "PUT",
        body: JSON.stringify({ value: entry.value, namespace: entry.namespace, status: entry.status }),
      });
      setEntries((current) => current.map((item) => item.key === entry.key ? saved : item));
      setMessage(`${entry.key} saved.`);
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setSavingKey(null);
    }
  };

  const addEntry = async () => {
    if (!newKey.trim() || !newValue.trim()) return;
    const saved = await requestJson<TranslationEntry>(`/api/admin/translations/${encodeURIComponent(locale)}/${encodeURIComponent(newKey.trim())}`, {
      method: "PUT",
      body: JSON.stringify({ value: newValue.trim(), status: "published" }),
    });
    setEntries((current) => [...current.filter((entry) => entry.key !== saved.key), saved].sort((a, b) => a.key.localeCompare(b.key)));
    setNewKey("");
    setNewValue("");
    setMessage(`${saved.key} added.`);
  };

  const toggleLanguage = async (language: AdminLanguage) => {
    const updated = await requestJson<AdminLanguage>(`/api/admin/languages/${encodeURIComponent(language.code)}`, {
      method: "PATCH",
      body: JSON.stringify({ enabled: !language.enabled, direction: language.direction }),
    });
    setAdminLanguages((current) => current.map((item) => item.code === updated.code ? updated : item));
  };

  const updateContentField = (field: string, value: string) => {
    setContentTranslation((current) => ({ ...(current || { locale: contentLocale, status: "draft" }), [field]: value }));
  };

  const saveContentTranslation = async () => {
    if (!contentSlug || !contentTranslation) return;
    setContentSaving(true);
    const payload = contentType === "products" ? {
      name: String(contentTranslation.name || ""),
      category: String(contentTranslation.category || ""),
      description: String(contentTranslation.description || ""),
      origin: String(contentTranslation.origin || ""),
      quality: String(contentTranslation.quality || ""),
      specifications: String(contentTranslation.specificationsText || "").split("\n").map((value) => value.trim()).filter(Boolean),
      markets: String(contentTranslation.marketsText || "").split(",").map((value) => value.trim()).filter(Boolean),
      status: contentTranslation.status,
    } : {
      title: String(contentTranslation.title || ""),
      slug: String(contentTranslation.slug || contentSlug),
      excerpt: String(contentTranslation.excerpt || ""),
      body: String(contentTranslation.body || ""),
      status: contentTranslation.status,
    };
    try {
      const saved = await requestJson<ContentTranslation>(`/api/admin/${contentType}/${encodeURIComponent(contentSlug)}/translations/${encodeURIComponent(contentLocale)}`, {
        method: "PUT",
        body: JSON.stringify(payload),
      });
      setContentTranslation({
        ...saved,
        specificationsText: Array.isArray(saved.specifications) ? saved.specifications.join("\n") : saved.specificationsText,
        marketsText: Array.isArray(saved.markets) ? saved.markets.join(", ") : saved.marketsText,
      });
      setMessage(`${contentType === "products" ? "Product" : "Insight"} translation saved.`);
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setContentSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col gap-4 rounded-md border border-border bg-white p-6 shadow-sm md:flex-row md:items-end md:justify-between">
        <div>
          <p className="eyebrow mb-3">{t("admin.translations")}</p>
          <h1 className="font-serif text-3xl font-bold text-primary">{t("admin.translationTitle")}</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{t("admin.translationDescription")}</p>
        </div>
        <div className="flex items-center gap-3">
          <Languages className="h-5 w-5 text-accent" aria-hidden="true" />
          <label htmlFor="translation-locale" className="sr-only">{t("common.language")}</label>
          <select id="translation-locale" value={locale} onChange={(event) => setLocale(event.target.value)} className="h-10 border border-border bg-background px-3 text-sm text-primary outline-none focus:ring-2 focus:ring-accent">
            {languageOptions.map((language) => <option key={language.code} value={language.code}>{language.nativeName} — {language.name}</option>)}
          </select>
        </div>
      </header>

      {message && <div className="flex items-center gap-2 border border-accent/30 bg-accent/10 px-4 py-3 text-sm text-primary"><Check className="h-4 w-4 text-accent" aria-hidden="true" />{message}</div>}

      <section className="rounded-md border border-border bg-white p-6 shadow-sm">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-serif text-2xl font-bold text-primary">{t("admin.translations")}</h2>
            <p className="mt-1 text-sm text-muted-foreground">Publish the shared UI vocabulary used by public pages, forms, navigation, and SEO.</p>
          </div>
          <div className="relative w-full md:w-80">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("admin.searchTranslations")} className="pl-9" />
          </div>
        </div>

        <div className="mb-5 grid gap-3 rounded-sm border border-dashed border-border bg-muted/20 p-4 md:grid-cols-[1fr_1fr_auto]">
          <Input value={newKey} onChange={(event) => setNewKey(event.target.value)} placeholder="new.key.name" aria-label="New translation key" />
          <Input value={newValue} onChange={(event) => setNewValue(event.target.value)} placeholder="Translated value" aria-label="New translation value" />
          <Button onClick={addEntry} disabled={!newKey.trim() || !newValue.trim()} className="gap-2"><Save className="h-4 w-4" aria-hidden="true" />Add key</Button>
        </div>

        {loading ? <div className="p-8 text-center text-muted-foreground" role="status">{t("common.loading")}</div> : entries.length === 0 ? (
          <div className="border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No published or draft keys exist for this locale yet. Add the first key above.</div>
        ) : (
          <div className="space-y-3">
            {entries.map((entry) => (
              <div key={entry.key} className="grid gap-3 rounded-sm border border-border p-4 lg:grid-cols-[minmax(12rem,.7fr)_minmax(16rem,1.3fr)_auto] lg:items-center">
                <div className="min-w-0">
                  <code className="break-all text-xs font-semibold text-primary">{entry.key}</code>
                  <Badge variant={entry.status === "published" ? "accent" : "secondary"} className="mt-2">{entry.status}</Badge>
                </div>
                <Input value={entry.value} onChange={(event) => updateEntry(entry.key, event.target.value)} aria-label={`${entry.key} translation`} />
                <Button onClick={() => saveEntry(entry)} disabled={savingKey === entry.key} variant="outline" className="gap-2"><Save className="h-4 w-4" aria-hidden="true" />{t("admin.save")}</Button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="rounded-md border border-border bg-white p-6 shadow-sm">
        <div className="mb-6 flex items-start gap-3">
          <Globe2 className="mt-1 h-5 w-5 text-accent" aria-hidden="true" />
          <div><h2 className="font-serif text-2xl font-bold text-primary">{t("admin.languageTitle")}</h2><p className="mt-1 text-sm text-muted-foreground">{t("admin.languageDescription")}</p></div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {adminLanguages.map((language) => (
            <div key={language.code} className="flex items-center justify-between gap-3 border border-border p-4">
              <div className="min-w-0"><p className="truncate text-sm font-semibold text-primary">{language.nativeName}</p><p className="text-xs text-muted-foreground">{language.name} · {language.code} · {language.direction.toUpperCase()}</p></div>
              <Button size="sm" variant={language.enabled ? "default" : "outline"} onClick={() => toggleLanguage(language)}>{language.enabled ? t("admin.published") : "Enable"}</Button>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-md border border-border bg-white p-6 shadow-sm">
        <div className="mb-6">
          <p className="eyebrow mb-2">Localized catalogue and insights</p>
          <h2 className="font-serif text-2xl font-bold text-primary">Content translations</h2>
          <p className="mt-1 text-sm text-muted-foreground">Translate product and article fields while keeping the English record as the fallback.</p>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          <select value={contentType} onChange={(event) => { setContentType(event.target.value as "products" | "news"); setContentSlug(""); }} className="h-10 border border-border bg-background px-3 text-sm text-primary">
            <option value="products">Products</option>
            <option value="news">Insights</option>
          </select>
          <select value={contentSlug} onChange={(event) => setContentSlug(event.target.value)} className="h-10 border border-border bg-background px-3 text-sm text-primary">
            {contentItems.map((item) => <option key={item.slug} value={item.slug}>{item.name || item.title}</option>)}
          </select>
          <select value={contentLocale} onChange={(event) => setContentLocale(event.target.value)} className="h-10 border border-border bg-background px-3 text-sm text-primary">
            {languageOptions.map((language) => <option key={language.code} value={language.code}>{language.nativeName} — {language.code}</option>)}
          </select>
        </div>
        {contentLoading ? <div className="p-8 text-center text-muted-foreground" role="status">{t("common.loading")}</div> : contentTranslation && (
          <div className="mt-5 space-y-4">
            {contentType === "products" ? (
              <div className="grid gap-4 md:grid-cols-2">
                <Input value={String(contentTranslation.name || "")} onChange={(event) => updateContentField("name", event.target.value)} placeholder="Product name" aria-label="Translated product name" />
                <Input value={String(contentTranslation.category || "")} onChange={(event) => updateContentField("category", event.target.value)} placeholder="Category" aria-label="Translated category" />
                <Textarea value={String(contentTranslation.description || "")} onChange={(event) => updateContentField("description", event.target.value)} placeholder="Description" aria-label="Translated product description" className="md:col-span-2" />
                <Input value={String(contentTranslation.origin || "")} onChange={(event) => updateContentField("origin", event.target.value)} placeholder="Origin" aria-label="Translated origin" />
                <Input value={String(contentTranslation.quality || "")} onChange={(event) => updateContentField("quality", event.target.value)} placeholder="Quality statement" aria-label="Translated quality statement" />
                <Textarea value={String(contentTranslation.specificationsText || (Array.isArray(contentTranslation.specifications) ? contentTranslation.specifications.join("\n") : ""))} onChange={(event) => updateContentField("specificationsText", event.target.value)} placeholder="One specification per line" aria-label="Translated specifications" />
                <Textarea value={String(contentTranslation.marketsText || (Array.isArray(contentTranslation.markets) ? contentTranslation.markets.join(", ") : ""))} onChange={(event) => updateContentField("marketsText", event.target.value)} placeholder="Markets, separated by commas" aria-label="Translated markets" />
              </div>
            ) : (
              <div className="space-y-4">
                <Input value={String(contentTranslation.title || "")} onChange={(event) => updateContentField("title", event.target.value)} placeholder="Insight title" aria-label="Translated insight title" />
                <Input value={String(contentTranslation.slug || contentSlug)} onChange={(event) => updateContentField("slug", event.target.value)} placeholder="Localized slug" aria-label="Localized insight slug" />
                <Textarea value={String(contentTranslation.excerpt || "")} onChange={(event) => updateContentField("excerpt", event.target.value)} placeholder="Excerpt" aria-label="Translated insight excerpt" />
                <Textarea value={String(contentTranslation.body || "")} onChange={(event) => updateContentField("body", event.target.value)} placeholder="Article body" aria-label="Translated insight body" className="min-h-48" />
              </div>
            )}
            <div className="flex flex-wrap justify-end gap-3">
              <select value={contentTranslation.status} onChange={(event) => updateContentField("status", event.target.value)} className="h-10 border border-border bg-background px-3 text-sm text-primary" aria-label="Translation status">
                <option value="draft">Draft</option><option value="published">Published</option>
              </select>
              <Button onClick={saveContentTranslation} disabled={contentSaving} className="gap-2"><Save className="h-4 w-4" aria-hidden="true" />{t("admin.save")}</Button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}