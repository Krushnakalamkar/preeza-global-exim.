import { useState } from "react"
import { useListEnquiries, useUpdateEnquiryStatus } from "@workspace/api-client-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useQueryClient } from "@tanstack/react-query"
import { getListEnquiriesQueryKey } from "@workspace/api-client-react"
import { useToast } from "@/hooks/use-toast"

export default function AdminEnquiries() {
  const { data: enquiries, isLoading } = useListEnquiries()
  const updateStatus = useUpdateEnquiryStatus()
  const queryClient = useQueryClient()
  const { toast } = useToast()

  const handleStatusChange = (id: number, currentStatus: string) => {
    // Simple state machine: new -> contacted -> qualified -> closed
    let nextStatus: "new" | "contacted" | "qualified" | "closed" = "contacted"
    if (currentStatus === "new") nextStatus = "contacted"
    else if (currentStatus === "contacted") nextStatus = "qualified"
    else if (currentStatus === "qualified") nextStatus = "closed"
    else return

    updateStatus.mutate(
      { id, data: { status: nextStatus } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListEnquiriesQueryKey() })
          toast({ title: "Status updated" })
        }
      }
    )
  }

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "new": return <Badge variant="destructive">New</Badge>
      case "contacted": return <Badge variant="outline">Contacted</Badge>
      case "qualified": return <Badge variant="accent">Qualified</Badge>
      case "closed": return <Badge variant="secondary">Closed</Badge>
      default: return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="font-serif text-3xl font-bold text-primary mb-2">Enquiries</h1>
          <p className="text-muted-foreground">Manage incoming trade requests and messages.</p>
        </div>
      </div>

      <div className="bg-white border border-border rounded-md shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading enquiries...</div>
        ) : !enquiries || enquiries.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No enquiries found.</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ref ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {enquiries.map((enq) => (
                <TableRow key={enq.id}>
                  <TableCell className="font-mono text-xs">{enq.enquiryId}</TableCell>
                  <TableCell>{new Date(enq.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="font-medium">{enq.company}</div>
                    <div className="text-xs text-muted-foreground">{enq.name}</div>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate">{enq.subject}</TableCell>
                  <TableCell>{getStatusBadge(enq.status)}</TableCell>
                  <TableCell className="text-right">
                    {enq.status !== "closed" && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleStatusChange(enq.id, enq.status)}
                        disabled={updateStatus.isPending}
                      >
                        Advance Status
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  )
}
