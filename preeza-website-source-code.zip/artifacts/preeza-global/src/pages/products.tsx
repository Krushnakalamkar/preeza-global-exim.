import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Download, FileCheck, Leaf, Search, ShieldCheck, Ship, Users } from "lucide-react";
import { Seo } from "@/components/seo";
import { Reveal } from "@/components/ui/reveal";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

const verticals = [
  { number: "01", title: "Food Ingredients & Nutraceuticals", image: siteImages.foodBanner, href: "/products/food-ingredients", accent: "text-[#3f754c]", items: ["Turmeric Powder", "Banana Powder", "Onion Powder", "Pomegranate Powder"], line: "Pure ingredients. Global possibilities." },
  { number: "02", title: "Jewellery Collections", image: siteImages.brassProducts, href: "/products/jewellery", accent: "text-primary", items: ["Lab-grown diamond jewellery", "Fashion jewellery", "Rings, earrings & necklaces"], line: "Crafted to shine. Designed to inspire." },
  { number: "03", title: "Handicrafts & Home Décor", image: siteImages.potteryImage, href: "/products/handicrafts", accent: "text-[#ae771d]", items: ["Brass artefacts", "Wooden carvings", "Brass lanterns", "Decorative collections"], line: "Crafted in India. Cherished worldwide." },
  { number: "04", title: "Indian Heritage Collections", image: siteImages.artisansCollage, href: "/products/heritage", accent: "text-[#8c3e4b]", items: ["Pashmina shawls", "Hand-block prints", "Heritage textiles", "Furnishing collections"], line: "Traditions woven for the world." },
];

const process = [
  { title: "Market assessment", icon: Search },
  { title: "Supplier evaluation", icon: Users },
  { title: "Product qualification", icon: CheckCircle2 },
  { title: "Quality verification", icon: ShieldCheck },
  { title: "Global export readiness", icon: Ship },
];

export default function Products() {
  return (
    <div className="bg-[#f8f7f3] text-primary">
      <Seo title="Our Products" description="Explore Preeza Global's four strategic product verticals, carefully sourced from trusted Indian manufacturers and verified for global standards." />
      <section className="bg-[#eef3f8]">
        <div className="container mx-auto grid items-center gap-8 px-4 py-12 md:px-8 lg:grid-cols-[.82fr_1.18fr] lg:py-14">
          <div><p className="eyebrow mb-4">A considered catalogue</p><h1 className="display-title text-5xl leading-none text-primary md:text-6xl">Our <em className="not-italic text-accent">products.</em></h1><p className="mt-5 max-w-lg text-sm leading-relaxed text-primary/70">A diverse range of high-quality products across four strategic verticals, carefully sourced from trusted Indian manufacturers and verified for global standards.</p><Link href="/contact?type=catalogue" className="mt-7 inline-flex h-12 items-center rounded-sm bg-primary px-6 text-xs font-bold uppercase tracking-[.14em] text-white hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">Request product catalogue <Download className="ml-3 h-4 w-4" aria-hidden="true" /></Link></div>
          <div className="grid grid-cols-2 gap-2 sm:gap-3"><ImageWithFallback src={siteImages.foodBanner} alt="Indian spice and fruit powders" loading="eager" fetchPriority="high" className="h-44 w-full rounded-sm object-cover sm:h-56" /><ImageWithFallback src={siteImages.brassProducts} alt="Indian brass product collection" loading="lazy" className="h-44 w-full rounded-sm object-cover sm:h-56" /><ImageWithFallback src={siteImages.potteryImage} alt="Indian pottery and home décor" loading="lazy" className="h-44 w-full rounded-sm object-cover sm:h-56" /><ImageWithFallback src={siteImages.artisansCollage} alt="Indian artisans and heritage craft" loading="lazy" className="h-44 w-full rounded-sm object-cover sm:h-56" /></div>
        </div>
      </section>

      <section className="py-14 md:py-20">
        <div className="container mx-auto px-4 md:px-8"><Reveal><div className="mb-8 text-center"><p className="eyebrow mb-3">The Preeza catalogue</p><h2 className="display-title text-4xl text-primary md:text-5xl">Our strategic business verticals</h2></div></Reveal>
          <div className="grid gap-5 lg:grid-cols-2">{verticals.map((vertical, index) => <Reveal key={vertical.title} delay={index * 70}><article className="group overflow-hidden rounded-sm border border-primary/10 bg-white"><div className="relative h-48 overflow-hidden"><span className="absolute left-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/95 text-xs font-bold text-primary shadow-sm">{vertical.number}</span><ImageWithFallback src={vertical.image} alt={vertical.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" /></div><div className="p-6 md:p-7"><h3 className={`text-lg font-bold uppercase tracking-wide ${vertical.accent}`}>{vertical.title}</h3><div className="mt-5 grid gap-2 sm:grid-cols-2">{vertical.items.map((item) => <span key={item} className="flex items-start gap-2 text-xs text-primary/70"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" aria-hidden="true" />{item}</span>)}</div><div className="mt-6 flex items-center justify-between border-t border-primary/10 pt-4"><span className="text-xs italic text-primary/55">{vertical.line}</span><Link href={vertical.href} className={`flex items-center gap-1 text-[10px] font-bold uppercase tracking-[.12em] ${vertical.accent} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent`}>Explore <ArrowRight className="h-3 w-3" aria-hidden="true" /></Link></div></div></article></Reveal>)}</div>
        </div>
      </section>

      <section className="border-y border-primary/10 bg-white py-14"><div className="container mx-auto grid gap-12 px-4 md:px-8 lg:grid-cols-[.95fr_1.05fr]"><div><p className="eyebrow mb-3">A clear path from brief to shipment</p><h2 className="display-title text-4xl text-primary">Our product selection process</h2><p className="mt-4 max-w-md text-sm leading-relaxed text-primary/65">Every product is reviewed for capability, consistency and export readiness before it becomes part of the catalogue.</p><div className="mt-7 flex items-center gap-3 text-sm font-semibold text-primary"><FileCheck className="h-5 w-5 text-accent" aria-hidden="true" /> Documentation that travels with the product</div></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-5">{process.map((step, index) => <div key={step.title} className="relative text-center"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full border border-accent/60 bg-[#fbfaf7] text-primary"><step.icon className="h-5 w-5" aria-hidden="true" /></div><span className="mt-3 block text-[10px] font-bold uppercase leading-tight tracking-wide text-primary">{step.title}</span><span className="mt-1 block text-[10px] text-accent">0{index + 1}</span></div>)}</div></div></section>

      <section className="bg-primary py-10 text-white"><div className="container mx-auto flex flex-col items-start justify-between gap-6 px-4 md:flex-row md:items-center md:px-8"><div><p className="eyebrow mb-2">For international buyers</p><h2 className="display-title text-3xl">Looking for a trusted sourcing partner?</h2><p className="mt-2 text-sm text-blue-100/75">Share your requirements and we will connect you with the right products and reliable Indian suppliers.</p></div><Link href="/contact" className="inline-flex h-12 shrink-0 items-center rounded-sm bg-accent px-6 text-xs font-bold uppercase tracking-[.14em] text-primary hover:bg-[#d59a2c] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">Get in touch <ArrowRight className="ml-3 h-4 w-4" aria-hidden="true" /></Link></div></section>
    </div>
  );
}