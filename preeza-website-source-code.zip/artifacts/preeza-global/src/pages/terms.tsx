import { Link } from "wouter";

export default function Terms() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="bg-white py-16 lg:py-20 border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-8 text-center max-w-3xl">
          <h1 className="font-serif text-3xl md:text-4xl text-[#062E66] font-bold leading-tight mb-6 uppercase">
            Terms of Service
          </h1>
          <div className="h-[2px] w-16 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-gray-500 font-medium">Last updated: {new Date().toLocaleDateString()}</p>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 md:px-8 max-w-3xl">
          <div className="bg-white p-8 md:p-12 border border-gray-200 shadow-sm prose prose-blue prose-sm max-w-none text-gray-600">
            <h2 className="text-[#062E66] font-serif uppercase tracking-wide">1. Acceptance of Terms</h2>
            <p>
              By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">2. Business Nature</h2>
            <p>
              Preeza Global Exim Solutions operates as a B2B export and sourcing company. All product specifications,
              certifications, and pricing provided on this website or through our representatives are subject to final
              confirmation in a formal commercial invoice or contract.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">3. Intellectual Property</h2>
            <p>
              All content included on this site, such as text, graphics, logos, images, and software, is the property of
              Preeza Global Exim Solutions or its content suppliers and protected by international copyright laws.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">4. Limitation of Liability</h2>
            <p>
              Preeza Global Exim Solutions shall not be liable for any special or consequential damages that result from
              the use of, or the inability to use, the materials on this site or the performance of the products.
            </p>

            <h2 className="text-[#062E66] font-serif uppercase tracking-wide mt-8">5. Governing Law</h2>
            <p>
              Any claim relating to Preeza Global Exim Solutions's web site shall be governed by the laws of India,
              without regard to its conflict of law provisions. Jurisdiction for any disputes shall lie exclusively in
              the courts of Pune, Maharashtra, India.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}