import { useRoute, Link } from "wouter";
import { getGetNewsQueryKey, useGetNews } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, Share2, ArrowRight } from "lucide-react";
import { Seo } from "@/components/seo";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { useToast } from "@/hooks/use-toast";
import { safeAnalyticsSlug, trackEvent } from "@/lib/analytics";
import { useI18n } from "@/lib/i18n";

export default function InsightDetail() {
  const [, params] = useRoute("/insights/:slug");
  const slug = params?.slug || "";
  const analyticsSlug = safeAnalyticsSlug(slug) || "unknown";
  const { toast } = useToast();
  const { locale, localizedPath } = useI18n();

  const { data: article, isLoading, isError } = useGetNews(slug, {
    query: { enabled: !!slug, queryKey: [...getGetNewsQueryKey(slug), locale] },
    request: { headers: { "Accept-Language": locale } },
  });

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: article?.title,
          text: article?.excerpt,
          url: window.location.href,
        });
        trackEvent("article_shared", { article_slug: analyticsSlug, method: "native_share" });
      } catch (err) {
        // user cancelled or share failed
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        trackEvent("article_shared", { article_slug: analyticsSlug, method: "clipboard" });
        toast({
          title: "Link Copied",
          description: "Article link copied to clipboard.",
        });
      } catch {
        toast({
          title: "Unable to Copy Link",
          description: "Please copy the page address from your browser.",
          variant: "destructive",
        });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-24 flex justify-center bg-[#F8F8F5]">
        <div className="animate-pulse flex flex-col items-center w-full max-w-4xl px-4">
          <div className="h-12 w-3/4 bg-gray-200 mb-8 rounded"></div>
          <div className="h-64 w-full bg-gray-200 mb-8 rounded"></div>
          <div className="h-4 w-full max-w-2xl bg-gray-200 mb-4 rounded"></div>
          <div className="h-4 w-3/4 max-w-2xl bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (isError || !article) {
    return (
      <div className="min-h-screen pt-32 pb-24 container mx-auto px-4 text-center bg-[#F8F8F5]">
        <h2 className="text-2xl font-serif font-bold text-[#062E66] mb-4">Article Not Found</h2>
        <Link href={localizedPath("/insights")}>
          <Button variant="outline" className="border-[#062E66] text-[#062E66]">Return to Insights</Button>
        </Link>
      </div>
    );
  }

  // Parse paragraphs manually to avoid dangerouslySetInnerHTML
  const paragraphs = article.body.split('\n').filter(p => p.trim() !== '');

  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <Seo 
        title={article.title} 
        description={article.excerpt}
        type="article"
        image={article.imageUrl}
        schema={{
          "@context": "https://schema.org",
          "@type": "Article",
          "headline": article.title,
          "image": article.imageUrl ? [article.imageUrl] : [],
          "datePublished": article.publishedAt,
          "description": article.excerpt,
          "author": {
            "@type": "Organization",
            "name": "Preeza Global Exim Solutions"
          }
        }}
      />
      {/* Breadcrumb */}
      <div className="border-b border-gray-200 bg-white">
        <div className="container mx-auto px-4 md:px-8 py-3 flex items-center text-[10px] uppercase font-bold tracking-widest text-gray-500">
          <Link href="/" className="hover:text-[#062E66] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary rounded-sm p-1">Home</Link>
          <span className="mx-2" aria-hidden="true">›</span>
          <Link href="/insights" className="hover:text-[#062E66] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary rounded-sm p-1">Insights</Link>
          <span className="mx-2" aria-hidden="true">›</span>
          <span className="text-[#062E66] p-1" aria-current="page">{article.title.substring(0, 30)}...</span>
        </div>
      </div>

      <article className="py-16 md:py-24 container mx-auto px-4 md:px-8 max-w-4xl">
        <header className="mb-12 text-center">
          <div className="flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-6">
            <Calendar className="h-3 w-3" aria-hidden="true" />
            <time dateTime={article.publishedAt}>
              {new Date(article.publishedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
            </time>
          </div>
          <h1 className="font-serif text-3xl md:text-5xl font-bold text-[#062E66] mb-8 leading-tight uppercase">
            {article.title}
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-8" aria-hidden="true"></div>
        </header>

        {article.imageUrl && (
          <div className="aspect-[21/9] w-full border border-gray-200 bg-white mb-16 overflow-hidden shadow-sm">
            <ImageWithFallback src={article.imageUrl} alt="" fetchPriority="high" className="w-full h-full object-cover" />
          </div>
        )}

        <div className="prose prose-lg prose-blue max-w-none prose-headings:font-serif prose-headings:text-[#062E66] prose-headings:uppercase prose-p:text-gray-600 prose-p:font-medium prose-p:leading-relaxed prose-a:text-[#0A4EA9]">
          {paragraphs.map((p, idx) => (
            <p key={idx}>{p}</p>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-6">
          <Link href="/insights">
            <Button variant="outline" className="h-12 px-8 text-xs font-bold tracking-widest uppercase border-[#062E66] text-[#062E66] hover:bg-gray-50 rounded-none group">
              <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" aria-hidden="true" /> Back to Insights
            </Button>
          </Link>
          <Button 
            onClick={handleShare}
            variant="outline" 
            className="h-12 px-8 text-xs font-bold tracking-widest uppercase border-gray-300 text-gray-600 hover:bg-gray-50 rounded-none gap-2"
          >
            <Share2 className="h-4 w-4" aria-hidden="true" /> Share Article
          </Button>
        </div>
      </article>

      <section className="bg-[#062E66] py-16 border-t-4 border-[#F2B51D] text-center">
        <div className="container mx-auto px-4">
          <h3 className="font-serif text-3xl font-bold text-white mb-4 uppercase">Looking for Expert Market Guidance?</h3>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">Connect with our team to discuss how global market trends impact your specific sourcing requirements.</p>
          <Link href="/contact">
            <Button className="h-12 px-10 text-xs font-bold tracking-widest uppercase bg-[#F2B51D] hover:bg-[#d69f17] text-[#062E66] rounded-none group">
              Contact Our Experts <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}