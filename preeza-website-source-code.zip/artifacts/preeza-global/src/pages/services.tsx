import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe, ShieldCheck, CheckSquare, Target, Ship } from "lucide-react";
import { ImageWithFallback } from "@/components/ui/image-with-fallback";
import { siteImages } from "@/lib/site-images";

export default function Services() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F8F8F5]">
      <section className="relative overflow-hidden bg-[#062E66] py-16 lg:py-20 border-b border-gray-200">
        <ImageWithFallback src={siteImages.heroBanner} alt="" aria-hidden="true" loading="eager" className="absolute inset-0 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 bg-[#062E66]/65" aria-hidden="true" />
        <div className="container relative z-10 mx-auto px-4 md:px-8 text-center max-w-3xl">
          <span className="text-[#F2B51D] text-xs font-bold uppercase tracking-widest mb-4 block">WHAT WE DO</span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white font-bold leading-tight mb-6 uppercase">
            Our Services
          </h1>
          <div className="h-[2px] w-24 bg-[#F2B51D] mx-auto mb-6"></div>
          <p className="text-sm text-white/85 font-medium leading-relaxed">
            End-to-end export solutions bridging the gap between Indian manufacturers and global buyers with precision and reliability.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <div className="bg-white p-8 border border-gray-200 shadow-sm border-t-4 border-[#062E66] group hover:-translate-y-1 transition-transform">
              <SearchIcon className="w-10 h-10 text-[#F2B51D] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Product Sourcing</h3>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Identifying and partnering with the most capable and reliable manufacturers across India to meet exact global specifications.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#062E66]" /> Requirement Analysis
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#062E66]" /> Supplier Identification
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#062E66]" /> Capability Audits
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 border border-gray-200 shadow-sm border-t-4 border-[#F2B51D] group hover:-translate-y-1 transition-transform">
              <ShieldCheck className="w-10 h-10 text-[#062E66] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Quality Assurance</h3>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Implementing rigorous quality control measures at every stage of the procurement cycle to guarantee international standards.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#F2B51D]" /> Factory Audits
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#F2B51D]" /> In-Process Inspections
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#F2B51D]" /> Pre-Shipment Checks
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 border border-gray-200 shadow-sm border-t-4 border-[#8A1538] group hover:-translate-y-1 transition-transform">
              <Ship className="w-10 h-10 text-[#8A1538] mb-6" />
              <h3 className="font-serif text-xl font-bold text-[#062E66] mb-4 uppercase">Export Logistics</h3>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Managing end-to-end documentation, compliance, and shipping to ensure timely and secure delivery to global ports.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#8A1538]" /> Documentation Support
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#8A1538]" /> Freight Management
                </li>
                <li className="flex items-start gap-2 text-xs font-bold text-gray-700 uppercase tracking-wide">
                  <CheckSquare className="w-4 h-4 text-[#8A1538]" /> Customs Clearance
                </li>
              </ul>
            </div>

          </div>
        </div>
      </section>

      <section className="bg-[#EEF5FC] py-16 border-t-2 border-[#062E66] text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-serif text-3xl font-bold text-[#062E66] mb-4 uppercase">Ready to Source with Confidence?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto font-medium">Let our experts handle the complexities of international trade while you focus on growing your business.</p>
          <Link href="/contact">
            <Button className="h-12 px-10 text-xs font-bold tracking-widest uppercase bg-[#062E66] hover:bg-[#0A4EA9] text-white rounded-none group">
              Discuss Your Requirements <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}

function SearchIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}