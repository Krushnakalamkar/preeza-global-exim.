import { useState } from "react";
import { Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackClassName?: string;
  fetchPriority?: "high" | "low" | "auto";
}

export function ImageWithFallback({
  src,
  alt,
  className,
  fallbackClassName,
  loading = "lazy",
  decoding = "async",
  fetchPriority,
  ...props
}: ImageWithFallbackProps) {
  const [error, setError] = useState(false);

  if (error || !src) {
    return (
      <div className={cn("flex items-center justify-center bg-gray-100 text-gray-300 w-full h-full", className, fallbackClassName)}>
        <ImageIcon className="w-10 h-10 opacity-30" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt || "Image"}
      loading={loading}
      decoding={decoding}
      fetchPriority={fetchPriority}
      onError={() => setError(true)}
      className={className}
      {...props}
    />
  );
}
