import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Menu, X, ChevronDown, MessageCircle, ArrowUpRight } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { QuickEnquiryDialog } from "./QuickEnquiryDialog";
import {
  QUICK_ENQUIRY_PHONE_DISPLAY,
  QUICK_ENQUIRY_WHATSAPP,
} from "@/lib/contact";
import { useI18n } from "@/lib/i18n";

export function Navbar() {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t, language, languages, setLocale, localizedPath } = useI18n();
  const mainNavLinks = useMemo(() => [
    { name: t("nav.home"), href: "/" },
    { name: t("nav.about"), href: "/about" },
    {
      name: t("nav.products"),
      href: "/products",
      dropdown: [
        { name: t("nav.products.all"), href: "/products" },
        { name: t("nav.products.food"), href: "/products/food-ingredients" },
        { name: t("nav.products.jewellery"), href: "/products/jewellery" },
        { name: t("nav.products.handicrafts"), href: "/products/handicrafts" },
        { name: t("nav.products.heritage"), href: "/products/heritage" },
      ],
    },
    { name: t("nav.quality"), href: "/quality-compliance" },
    {
      name: t("nav.company"),
      href: "#",
      dropdown: [
        { name: t("nav.why"), href: "/why-preeza" },
        { name: t("nav.profile"), href: "/company-profile" },
        { name: t("nav.markets"), href: "/global-markets" },
        { name: t("nav.industries"), href: "/industries" },
        { name: t("nav.services"), href: "/services" },
      ],
    },
    { name: t("nav.insights"), href: "/insights" },
    { name: t("nav.contact"), href: "/contact" },
  ], [t]);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#d9e0e8] bg-[#fbfaf7]/95 backdrop-blur-md">
      <div className="container mx-auto flex h-[74px] items-center justify-between px-4 md:px-7">
        
        {/* Logo Section */}
        <Link href={localizedPath("/")} className="flex shrink-0 items-center" aria-label={t("nav.logoAlt")}>
          <img
            src="/preeza-logo.webp"
            alt="Preeza Global Exim Solutions — Connecting Markets Worldwide"
            width={240}
            height={70}
            fetchPriority="high"
            className="h-auto w-[158px] sm:w-[190px] lg:w-[205px]"
          />
        </Link>

        {/* Desktop Nav */}
        <nav aria-label={t("nav.mainNavigation")} className="hidden xl:flex items-center h-full">
          {mainNavLinks.map((link) => (
            <div key={link.name} className="relative h-full flex items-center group px-3 2xl:px-4">
              {link.href !== "#" ? (
                <Link
                  href={localizedPath(link.href)}
                  className={cn(
                     "text-[10px] font-bold tracking-[0.12em] uppercase whitespace-nowrap transition-colors flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent rounded-sm p-1",
                     location === link.href || link.dropdown?.some(d => location === d.href) ? "text-primary" : "text-primary/70 hover:text-primary"
                  )}
                  aria-haspopup={link.dropdown ? "true" : undefined}
                >
                  {link.name}
                  {link.dropdown && <ChevronDown className="h-3 w-3" aria-hidden="true" />}
                </Link>
              ) : (
                <button 
                  className={cn(
                      "text-[10px] font-bold tracking-[0.12em] uppercase whitespace-nowrap transition-colors flex items-center gap-1 text-primary/70 group-hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent rounded-sm p-1"
                  )}
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  {link.name}
                  {link.dropdown && <ChevronDown className="h-3 w-3" aria-hidden="true" />}
                </button>
              )}
              
              {/* Active Indicator */}
              {(location === link.href || (link.dropdown && link.dropdown.some(d => location === d.href))) && (
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-accent" aria-hidden="true"></div>
              )}
              
              {/* Dropdown Menu */}
              {link.dropdown && (
                 <div className="absolute top-[calc(100%-1px)] left-0 w-72 bg-[#fbfaf7] border border-[#d9e0e8] shadow-[0_18px_40px_rgba(5,24,55,.12)] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform translate-y-2 group-hover:translate-y-0 z-50 flex flex-col py-3">
                  {link.dropdown.map((drop) => (
                    <Link
                      key={drop.name}
                      href={localizedPath(drop.href)}
                      className={cn(
                         "px-5 py-2.5 text-[11px] tracking-wide text-primary/80 hover:text-primary hover:bg-[#eef3f7] transition-colors",
                         location === drop.href && "text-primary bg-[#eef3f7] font-bold"
                      )}
                    >
                      {drop.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden xl:flex items-center gap-4">
          <QuickEnquiryDialog className="uppercase text-[10px] font-bold tracking-[0.15em] bg-primary hover:bg-secondary text-white rounded-sm px-5 h-10 group">
            {t("nav.enquire")}
            <ArrowUpRight className="ml-2 h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
          </QuickEnquiryDialog>
          <div className="flex items-center gap-2 text-primary font-medium text-[11px]">
            <MessageCircle className="h-4 w-4 text-[#209a68]" />
            <a href={QUICK_ENQUIRY_WHATSAPP} target="_blank" rel="noopener noreferrer" className="hover:text-accent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
              <span dir="ltr">+91 {QUICK_ENQUIRY_PHONE_DISPLAY.replace("+91 ", "")}</span>
            </a>
          </div>
        </div>

        {/* Mobile Toggle */}
        <div className="hidden xl:flex items-center gap-2 mr-1">
          <label htmlFor="site-language" className="sr-only">{t("common.language")}</label>
          <select
            id="site-language"
            value={language.code}
            onChange={(event) => setLocale(event.target.value)}
            className="max-w-[120px] border-0 bg-transparent text-[10px] font-bold uppercase tracking-[0.12em] text-primary/75 outline-none focus:ring-2 focus:ring-accent"
          >
            {languages.map((item) => (
              <option key={item.code} value={item.code}>{item.nativeName}</option>
            ))}
          </select>
        </div>

        <button
           className="xl:hidden p-2 text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent rounded-sm"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-expanded={mobileOpen}
           aria-label={t("nav.toggle")}
          aria-controls="mobile-nav"
        >
          {mobileOpen ? <X className="h-6 w-6" aria-hidden="true" /> : <Menu className="h-6 w-6" aria-hidden="true" />}
        </button>
      </div>

      {/* Mobile Nav */}
      <nav
        id="mobile-nav"
        aria-label={t("nav.mobileNavigation")}
        aria-hidden={!mobileOpen}
        className={cn(
         "xl:hidden border-t border-gray-100 bg-[#fbfaf7] px-4 space-y-2 overflow-y-auto transition-[max-height,opacity,transform,padding] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none",
          mobileOpen
            ? "visible max-h-[calc(100vh-5rem)] translate-y-0 py-4 opacity-100"
            : "invisible pointer-events-none max-h-0 -translate-y-2 py-0 opacity-0"
        )}
      >
          {mainNavLinks.map((link) => (
            <div key={link.name} className="flex flex-col border-b border-gray-50 pb-2">
              {link.href !== "#" ? (
                <Link
                    href={localizedPath(link.href)}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "py-2 text-sm font-bold tracking-wide uppercase transition-colors flex items-center justify-between",
                    location === link.href ? "text-primary" : "text-primary/70"
                  )}
                >
                  {link.name}
                </Link>
              ) : (
                <span className="py-2 text-sm font-bold tracking-wide uppercase text-primary/70">
                  {link.name}
                </span>
              )}
              
              {link.dropdown && (
                <div className="flex flex-col pl-4 pt-1 space-y-2">
                  {link.dropdown.map((drop) => (
                    <Link
                      key={drop.name}
                      href={localizedPath(drop.href)}
                      onClick={() => setMobileOpen(false)}
                      className={cn(
                        "text-sm transition-colors",
                        location === drop.href ? "text-primary font-bold" : "text-primary/70"
                      )}
                    >
                      {drop.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="pt-4 flex flex-col gap-4">
            <QuickEnquiryDialog className="w-full justify-center uppercase text-xs font-bold tracking-wider bg-primary hover:bg-primary/90 text-white rounded-none">
              {t("nav.enquire")}
            </QuickEnquiryDialog>
            <div className="flex items-center justify-center gap-2 text-primary font-medium text-sm bg-gray-50 p-3">
              <MessageCircle className="h-5 w-5 text-[#25D366]" />
              <a href={QUICK_ENQUIRY_WHATSAPP} target="_blank" rel="noopener noreferrer">
                <span dir="ltr">{QUICK_ENQUIRY_PHONE_DISPLAY}</span>
              </a>
            </div>
          </div>
          <div className="pt-2">
            <label htmlFor="mobile-site-language" className="sr-only">{t("common.language")}</label>
            <select
              id="mobile-site-language"
              value={language.code}
              onChange={(event) => setLocale(event.target.value)}
              className="w-full border border-gray-200 bg-white px-3 py-3 text-sm text-primary outline-none focus:ring-2 focus:ring-accent"
            >
              {languages.map((item) => (
                <option key={item.code} value={item.code}>{item.nativeName} — {item.name}</option>
              ))}
            </select>
          </div>
      </nav>
    </header>
  );
}