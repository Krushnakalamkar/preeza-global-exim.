import { ReactNode } from "react";
import { Link } from "wouter";
import { ArrowRight, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  QUICK_ENQUIRY_PHONE,
  QUICK_ENQUIRY_PHONE_DISPLAY,
  QUICK_ENQUIRY_WHATSAPP,
} from "@/lib/contact";
import { trackEvent } from "@/lib/analytics";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

export function QuickEnquiryDialog({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  const { t, localizedPath } = useI18n();
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button type="button" className={cn(className)}>
          {children}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md rounded-none border-[#062E66]/15 bg-white p-6 sm:p-8">
        <DialogHeader className="text-left">
          <span className="mb-2 text-[10px] font-bold uppercase tracking-[0.22em] text-[#F2B51D]">
             {t("enquiry.title")}
          </span>
          <DialogTitle className="font-serif text-3xl font-bold text-[#062E66]">
             {t("enquiry.title")}
          </DialogTitle>
          <DialogDescription className="pt-2 text-sm leading-relaxed text-gray-600">
             {t("enquiry.description")}
          </DialogDescription>
        </DialogHeader>

        <div className="my-2 border-y border-gray-100 py-5 text-center">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500">
             {t("enquiry.call")}
          </p>
          <a
            href={`tel:${QUICK_ENQUIRY_PHONE}`}
            className="mt-2 inline-block font-serif text-2xl font-bold tracking-wide text-[#062E66] transition-colors hover:text-[#0A4EA9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F2B51D]"
          >
            <span dir="ltr">{QUICK_ENQUIRY_PHONE_DISPLAY}</span>
          </a>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <a
            href={QUICK_ENQUIRY_WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() =>
              trackEvent("whatsapp_cta_clicked", { location: "quick_enquiry_dialog" })
            }
            className="group"
          >
            <Button
              type="button"
              className="h-12 w-full rounded-none bg-[#25D366] text-xs font-bold uppercase tracking-wider text-white hover:bg-[#20bd5a]"
            >
              <MessageCircle className="mr-2 h-4 w-4" aria-hidden="true" />
              {t("enquiry.whatsapp")}
              <ArrowRight
                className="ml-auto h-4 w-4 transition-transform group-hover:translate-x-1"
                aria-hidden="true"
              />
            </Button>
          </a>
          <a
            href={`tel:${QUICK_ENQUIRY_PHONE}`}
            onClick={() =>
              trackEvent("phone_cta_clicked", { location: "quick_enquiry_dialog" })
            }
            className="group"
          >
            <Button
              type="button"
              variant="outline"
              className="h-12 w-full rounded-none border-[#062E66] text-xs font-bold uppercase tracking-wider text-[#062E66] hover:bg-[#062E66] hover:text-white"
            >
              <Phone className="mr-2 h-4 w-4" aria-hidden="true" />
              {t("enquiry.call")}
              <ArrowRight
                className="ml-auto h-4 w-4 transition-transform group-hover:translate-x-1"
                aria-hidden="true"
              />
            </Button>
          </a>
        </div>

        <DialogFooter className="mt-2 flex-col gap-2 sm:flex-col sm:space-x-0">
          <DialogClose asChild>
            <Link
              href={localizedPath("/contact?type=enquiry&source=quick_enquiry")}
              className="inline-flex h-10 items-center justify-center text-xs font-bold uppercase tracking-wider text-[#062E66] transition-colors hover:text-[#0A4EA9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F2B51D]"
            >
              {t("enquiry.form")}
            </Link>
          </DialogClose>
          <p className="text-center text-[10px] uppercase tracking-wider text-gray-400">
             {t("enquiry.hours")}
          </p>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}