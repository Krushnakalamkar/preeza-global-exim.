import { Link, useLocation } from "wouter"
import { ReactNode } from "react"
import { cn } from "@/lib/utils"
import { LayoutDashboard, Package, FileText, MessageSquare, LogOut, Globe, Languages } from "lucide-react"
import { useI18n } from "@/lib/i18n"

export function AdminLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation()
  const { t } = useI18n()
  const adminLinks = [
    { name: t("admin.dashboard"), href: "/admin", icon: LayoutDashboard },
    { name: t("admin.products"), href: "/admin/products", icon: Package },
    { name: t("admin.enquiries"), href: "/admin/enquiries", icon: MessageSquare },
    { name: t("admin.content"), href: "/admin/content", icon: FileText },
    { name: t("admin.translations"), href: "/admin/translations", icon: Languages },
  ]

  return (
    <div className="min-h-[100dvh] flex bg-muted/30">
      {/* Sidebar */}
      <aside className="w-64 bg-sidebar text-sidebar-foreground flex-shrink-0 hidden md:flex flex-col border-r border-sidebar-border">
        <div className="h-20 flex items-center px-6 border-b border-sidebar-border">
          <Link href="/" className="flex items-center gap-2 group">
            <Globe className="h-6 w-6 text-sidebar-ring group-hover:text-white transition-colors" />
            <span className="font-serif font-bold text-lg text-white tracking-wide uppercase">{t("admin.portal")}</span>
          </Link>
        </div>
        
        <nav className="flex-1 py-6 px-3 space-y-1">
          {adminLinks.map((link) => {
            const Icon = link.icon
            const isActive = location === link.href || (link.href !== "/admin" && location.startsWith(link.href))
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-3 rounded-md text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-white"
                )}
              >
                <Icon className="h-5 w-5" />
                {link.name}
              </Link>
            )
          })}
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <Link href="/">
            <button className="flex items-center gap-3 px-3 py-3 w-full rounded-md text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-white transition-colors">
              <LogOut className="h-5 w-5" />
              {t("admin.exit")}
            </button>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-20 bg-background border-b border-border flex items-center px-8 md:hidden">
          <span className="font-serif font-bold text-lg text-primary tracking-wide uppercase">{t("admin.portal")}</span>
        </header>
        <div className="flex-1 overflow-auto p-8">
          {children}
        </div>
      </main>
    </div>
  )
}
