import { ReactNode } from "react"
import { Navbar } from "./Navbar"
import { Footer } from "./Footer"

export function RootLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-accent selection:text-primary">
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  )
}
