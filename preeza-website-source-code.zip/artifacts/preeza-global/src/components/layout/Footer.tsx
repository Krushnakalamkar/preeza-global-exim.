import { Link } from "wouter";
import { Mail, MapPin, Phone, ArrowRight, Linkedin, Instagram } from "lucide-react";
import { COMPANY_ADDRESS, QUICK_ENQUIRY_PHONE, QUICK_ENQUIRY_PHONE_DISPLAY } from "@/lib/contact";
import { useI18n } from "@/lib/i18n";

export function Footer() {
  const { t, localizedPath } = useI18n();
  return (
    <footer className="bg-[#071d43] text-white border-t-2 border-accent">
      {/* CTA Strip */}
      <div className="border-b border-white/10 bg-[#0b2858]">
        <div className="container mx-auto px-4 md:px-8 py-8 lg:py-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl text-center md:text-left">
             <p className="eyebrow mb-3">A considered way to source from India</p>
             <h3 className="text-3xl font-serif text-white mb-2">Looking for a trusted sourcing partner?</h3>
             <p className="text-sm text-blue-100/80">
              Submit your requirements and our expert team will connect you with the right products and reliable Indian suppliers.
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center gap-6 mr-6 text-sm text-blue-100">
              <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent"></span> Timely Response</span>
              <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent"></span> Competitive Pricing</span>
              <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-accent"></span> Global Delivery</span>
            </div>
             <Link href={localizedPath("/contact")} className="inline-flex h-12 items-center bg-accent px-6 text-xs font-bold uppercase tracking-wider text-[#071d43] rounded-sm group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-[#0b2858]">
                 {t("nav.contact")} <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <Link href={localizedPath("/")} className="inline-block" aria-label={t("nav.logoAlt")}>
              <img
                src="/preeza-logo-footer.webp"
                alt="Preeza Global Exim Solutions — Connecting Markets Worldwide"
                width={300}
                height={88}
                loading="lazy"
                className="h-auto w-[240px]"
              />
            </Link>
            <p className="text-sm text-blue-100/80 leading-relaxed">
              Preeza Global EXIM Solutions bridges Indian excellence with international opportunities through responsible sourcing, rigorous supplier evaluation and unwavering commitment to quality.
            </p>
            <div>
              <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-accent">Connect with us</p>
              <div className="flex flex-wrap gap-3">
              <a href="https://www.linkedin.com/company/preeza-globalexim-solutions/about/?viewAsMember=true" target="_blank" rel="noreferrer" aria-label="LinkedIn — Preeza Global Exim Solutions" title="LinkedIn — Preeza Global Exim Solutions" className="inline-flex min-h-10 items-center gap-2 rounded bg-white/10 px-3 text-xs font-medium text-blue-100 transition-colors hover:bg-accent hover:text-[#062E66] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                <Linkedin className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Preeza Global</span>
              </a>
              <a href="https://www.instagram.com/preeza.exim/" target="_blank" rel="noreferrer" aria-label="Instagram — @preeza.exim" title="Instagram — @preeza.exim" className="inline-flex min-h-10 items-center gap-2 rounded bg-white/10 px-3 text-xs font-medium text-blue-100 transition-colors hover:bg-accent hover:text-[#062E66] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>@preeza.exim</span>
              </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-sm mb-6 text-white border-b border-white/20 pb-2 inline-block">Company</h4>
            <ul className="space-y-3 text-sm text-blue-100/80">
               <li><Link href={localizedPath("/about")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.about")}</Link></li>
               <li><Link href={localizedPath("/why-preeza")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.why")}</Link></li>
               <li><Link href={localizedPath("/quality-compliance")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.quality")}</Link></li>
               <li><Link href={localizedPath("/global-markets")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.markets")}</Link></li>
               <li><Link href={localizedPath("/insights")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.insights")}</Link></li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-sm mb-6 text-white border-b border-white/20 pb-2 inline-block">Product Verticals</h4>
            <ul className="space-y-3 text-sm text-blue-100/80">
               <li><Link href={localizedPath("/products/food-ingredients")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.products.food")}</Link></li>
               <li><Link href={localizedPath("/products/jewellery")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.products.jewellery")}</Link></li>
               <li><Link href={localizedPath("/products/handicrafts")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.products.handicrafts")}</Link></li>
               <li><Link href={localizedPath("/products/heritage")} className="hover:text-accent transition-colors flex items-center gap-2"><ArrowRight className="w-3 h-3 text-accent" /> {t("nav.products.heritage")}</Link></li>
               <li><Link href={localizedPath("/products")} className="hover:text-accent transition-colors flex items-center gap-2 mt-4 font-bold"><ArrowRight className="w-3 h-3 text-accent" /> {t("common.viewAll")}</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold uppercase tracking-wider text-sm mb-6 text-white border-b border-white/20 pb-2 inline-block">Contact Information</h4>
            <ul className="space-y-4 text-sm text-blue-100/80">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-accent shrink-0 mt-0.5" />
                 <span dir="ltr">{COMPANY_ADDRESS}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-accent shrink-0" />
                    <a dir="ltr" href="mailto:info@preezaglobal.com" className="hover:text-accent transition-colors">info@preezaglobal.com</a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-accent shrink-0" />
                    <a dir="ltr" href={`tel:${QUICK_ENQUIRY_PHONE}`} className="hover:text-accent transition-colors">{QUICK_ENQUIRY_PHONE_DISPLAY}</a>
              </li>
            </ul>
            
            <div className="mt-8">
              <p className="text-xs text-blue-100/60 mb-2 uppercase tracking-wider font-bold">Certifications & Registrations</p>
              <div className="flex flex-wrap gap-2">
                <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold border border-white/20">IEC</span>
                <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold border border-white/20">GST</span>
                <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold border border-white/20">MSME</span>
                <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold border border-white/20">FSSAI</span>
                <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold border border-white/20">APEDA</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 md:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-blue-100/60">
          <p>&copy; {new Date().getFullYear()} Preeza Global Exim Solutions. All rights reserved.</p>
          <div className="flex items-center gap-6">
             <Link href={localizedPath("/privacy")} className="hover:text-accent transition-colors">Privacy Policy</Link>
             <Link href={localizedPath("/terms")} className="hover:text-accent transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}