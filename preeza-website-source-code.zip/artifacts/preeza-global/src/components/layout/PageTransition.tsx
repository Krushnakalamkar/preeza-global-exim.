import { ReactNode } from "react";
import { useLocation } from "wouter";

export function PageTransition({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div
      key={location}
      className="page-transition-shell"
      data-route={location}
    >
      <span className="page-transition-line" aria-hidden="true" />
      {children}
    </div>
  );
}
