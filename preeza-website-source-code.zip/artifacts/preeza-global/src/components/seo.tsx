import { useEffect } from "react";
import { prefixLocale, useI18n } from "@/lib/i18n";

interface SeoProps {
  title: string;
  description: string;
  canonical?: string;
  type?: "website" | "article";
  image?: string;
  schema?: Record<string, unknown>;
}

export function Seo({ 
  title, 
  description, 
  canonical, 
  type = "website", 
  image = "/preeza-logo.webp",
  schema 
}: SeoProps) {
  const { locale, languages, t } = useI18n();
  useEffect(() => {
    const fullTitle = `${title} | ${t("seo.titleSuffix")}`;
    document.title = fullTitle;
    
    const setMeta = (name: string, content: string, isProperty = false) => {
      const attr = isProperty ? 'property' : 'name';
      let el = document.querySelector(`meta[${attr}="${name}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    setMeta('description', description);
    setMeta('og:title', fullTitle, true);
    setMeta('og:description', description, true);
    setMeta('og:type', type, true);
    setMeta('twitter:title', fullTitle);
    setMeta('twitter:description', description);
    setMeta('twitter:card', 'summary_large_image');

    if (image) {
      // Resolve absolute URL for images if it's relative
      const imageUrl = image.startsWith('http') ? image : `${window.location.origin}${image}`;
      setMeta('og:image', imageUrl, true);
      setMeta('twitter:image', imageUrl);
    }
    
    const canonicalUrl = canonical || `${window.location.origin}${window.location.pathname}`;
    let canonicalEl = document.querySelector('link[rel="canonical"]');
    if (!canonicalEl) {
      canonicalEl = document.createElement('link');
      canonicalEl.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalEl);
    }
    canonicalEl.setAttribute('href', canonicalUrl);
    setMeta('og:url', canonicalUrl, true);
    document.documentElement.lang = locale;
    const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
    document.querySelectorAll('link[data-preeza-hreflang="true"]').forEach((link) => link.remove());
    [...languages, { code: "x-default" }].forEach((language) => {
      const route = language.code === "x-default"
        ? prefixLocale(window.location.pathname, "en")
        : prefixLocale(window.location.pathname, language.code);
      const alternate = document.createElement("link");
      alternate.setAttribute("rel", "alternate");
      alternate.setAttribute("hreflang", language.code);
      alternate.setAttribute("data-preeza-hreflang", "true");
      alternate.setAttribute("href", `${window.location.origin}${basePath}${route === "/" ? "" : route}`);
      document.head.appendChild(alternate);
    });

    if (schema) {
      let scriptEl = document.querySelector('script[id="structured-data"]');
      if (!scriptEl) {
        scriptEl = document.createElement('script');
        scriptEl.setAttribute('type', 'application/ld+json');
        scriptEl.setAttribute('id', 'structured-data');
        document.head.appendChild(scriptEl);
      }
      scriptEl.textContent = JSON.stringify(schema);
    }

    return () => {
      const scriptEl = document.querySelector('script[id="structured-data"]');
      if (scriptEl) scriptEl.remove();
    };
  }, [locale, t, title, description, canonical, type, image, schema]);

  return null;
}
