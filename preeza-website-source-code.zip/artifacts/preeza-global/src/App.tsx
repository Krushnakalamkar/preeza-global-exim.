import { lazy, Suspense, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { RootLayout } from '@/components/layout/RootLayout';
import { PageTransition } from '@/components/layout/PageTransition';
import { Seo } from '@/components/seo';
import Home from '@/pages/home';
import { localeFromPath, useI18n } from '@/lib/i18n';

const AdminEntry = lazy(() => import('@/AdminEntry'));
const About = lazy(() => import('@/pages/about'));
const Products = lazy(() => import('@/pages/products'));
const ProductDetail = lazy(() => import('@/pages/product-detail'));
const Services = lazy(() => import('@/pages/services'));
const Industries = lazy(() => import('@/pages/industries'));
const GlobalMarkets = lazy(() => import('@/pages/global-markets'));
const QualityCompliance = lazy(() => import('@/pages/quality-compliance'));
const WhyPreeza = lazy(() => import('@/pages/why-preeza'));
const CompanyProfile = lazy(() => import('@/pages/company-profile'));
const Insights = lazy(() => import('@/pages/insights'));
const InsightDetail = lazy(() => import('@/pages/insight-detail'));
const Contact = lazy(() => import('@/pages/contact'));
const Privacy = lazy(() => import('@/pages/privacy'));
const Terms = lazy(() => import('@/pages/terms'));

const staticSeo: Record<string, { titleKey: string; descriptionKey: string }> = {
  "/services": { titleKey: "seo.servicesTitle", descriptionKey: "seo.servicesDescription" },
  "/industries": { titleKey: "seo.industriesTitle", descriptionKey: "seo.industriesDescription" },
  "/global-markets": { titleKey: "seo.marketsTitle", descriptionKey: "seo.marketsDescription" },
  "/quality-compliance": { titleKey: "seo.qualityTitle", descriptionKey: "seo.qualityDescription" },
  "/why-preeza": { titleKey: "seo.whyTitle", descriptionKey: "seo.whyDescription" },
  "/company-profile": { titleKey: "seo.profileTitle", descriptionKey: "seo.profileDescription" },
  "/insights": { titleKey: "seo.insightsTitle", descriptionKey: "seo.insightsDescription" },
  "/contact": { titleKey: "seo.contactTitle", descriptionKey: "seo.contactDescription" },
  "/privacy": { titleKey: "seo.privacyTitle", descriptionKey: "seo.privacyDescription" },
  "/terms": { titleKey: "seo.termsTitle", descriptionKey: "seo.termsDescription" },
};

function StaticRouteSeo() {
  const [location] = useLocation();
  const { t } = useI18n();
  const pathname = location.split("?")[0];
  const meta = staticSeo[pathname];
  return meta ? <Seo title={t(meta.titleKey)} description={t(meta.descriptionKey)} /> : null;
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
function Router() {
  const [location] = useLocation();
  if (location === "/admin" || location.startsWith("/admin/")) {
    return <Suspense fallback={<main className="min-h-screen bg-[#062E66]" />}><AdminEntry /></Suspense>;
  }
  return (
    <Switch>
      <Route>
        <RootLayout>
          <StaticRouteSeo />
          <PageTransition>
            <Suspense fallback={
              <div className="min-h-[60vh] flex items-center justify-center">
                <div className="animate-pulse w-12 h-12 rounded-full border-4 border-[#F2B51D] border-t-[#062E66] animate-spin"></div>
              </div>
            }>
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/about" component={About} />
                <Route path="/products" component={Products} />
                <Route path="/products/:slug" component={ProductDetail} />
                <Route path="/services" component={Services} />
                <Route path="/industries" component={Industries} />
                <Route path="/global-markets" component={GlobalMarkets} />
                <Route path="/quality-compliance" component={QualityCompliance} />
                <Route path="/why-preeza" component={WhyPreeza} />
                <Route path="/company-profile" component={CompanyProfile} />
                <Route path="/insights" component={Insights} />
                <Route path="/insights/:slug" component={InsightDetail} />
                <Route path="/contact" component={Contact} />
                <Route path="/privacy" component={Privacy} />
                <Route path="/terms" component={Terms} />
                <Route>
                  <Redirect to="/" />
                </Route>
              </Switch>
            </Suspense>
          </PageTransition>
        </RootLayout>
      </Route>
    </Switch>
  );
}

function LocaleRouter() {
  const [location] = useLocation();
  const locale = localeFromPath(location);
  return locale ? (
    <WouterRouter base={`/${locale}`}>
      <Router />
    </WouterRouter>
  ) : <Router />;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <RoutedErrorBoundary><LocaleRouter /></RoutedErrorBoundary>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function AppWithRouter() {
  return <WouterRouter base={basePath}><App /></WouterRouter>;
}

export default AppWithRouter;
