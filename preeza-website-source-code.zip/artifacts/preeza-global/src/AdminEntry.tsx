import { lazy, Suspense, useEffect, useState, type ReactNode } from "react";
import { ClerkProvider, Show, SignIn } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Route, Switch, useLocation } from "wouter";
import { AdminLayout } from "@/components/layout/AdminLayout";

const AdminDashboard = lazy(() => import("@/pages/admin/dashboard"));
const AdminProducts = lazy(() => import("@/pages/admin/products"));
const AdminContent = lazy(() => import("@/pages/admin/content"));
const AdminEnquiries = lazy(() => import("@/pages/admin/enquiries"));
const AdminTranslations = lazy(() => import("@/pages/admin/translations"));

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const configuredKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const appearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  variables: {
    colorPrimary: "#0A4EA9",
    colorForeground: "#17202A",
    colorMutedForeground: "#5f6975",
    colorBackground: "#FFFFFF",
    colorInput: "#F8F8F5",
    colorInputForeground: "#17202A",
    colorNeutral: "#d6dce4",
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif",
    borderRadius: "0px",
  },
};

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

function AdminGate({ children }: { children: ReactNode }) {
  const [access, setAccess] = useState<"checking" | "allowed" | "denied">("checking");
  useEffect(() => {
    let active = true;
    fetch("/api/admin/languages", { credentials: "include" })
      .then((response) => {
        if (active) setAccess(response.status === 403 ? "denied" : response.ok ? "allowed" : "checking");
      })
      .catch(() => { if (active) setAccess("checking"); });
    return () => { active = false; };
  }, []);
  return (
    <>
      <Show when="signed-in">
        {access === "checking" && <main className="min-h-screen bg-[#062E66] px-4 py-20 text-center text-white"><p>Checking administrator access…</p></main>}
        {access === "denied" && <main className="min-h-screen bg-[#062E66] px-4 py-20 flex items-center justify-center"><div className="max-w-md text-center text-white"><p className="text-[#F2B51D] text-xs font-bold tracking-[0.24em] uppercase mb-3">Administrator access required</p><h1 className="font-serif text-3xl">This account is not enabled for the admin portal.</h1></div></main>}
        {access === "allowed" && children}
      </Show>
      <Show when="signed-out">
        <main className="min-h-screen bg-[#062E66] px-4 py-20 flex items-center justify-center">
          <div className="w-full max-w-md">
            <div className="text-center text-white mb-8">
              <p className="text-[#F2B51D] text-xs font-bold tracking-[0.24em] uppercase mb-3">Secure administration</p>
              <h1 className="font-serif text-3xl">Preeza Global</h1>
            </div>
            <SignIn routing="path" path={`${basePath}/admin`} />
          </div>
        </main>
      </Show>
    </>
  );
}

function AdminRoutes() {
  return (
    <AdminGate>
      <AdminLayout>
        <Suspense fallback={<div className="p-8" role="status">Loading administration…</div>}>
          <Switch>
            <Route path="/admin/products" component={AdminProducts} />
            <Route path="/admin/enquiries" component={AdminEnquiries} />
            <Route path="/admin/content" component={AdminContent} />
            <Route path="/admin/translations" component={AdminTranslations} />
            <Route path="/admin" component={AdminDashboard} />
          </Switch>
        </Suspense>
      </AdminLayout>
    </AdminGate>
  );
}

export default function AdminEntry() {
  const [, setLocation] = useLocation();
  if (!configuredKey) {
    return <main className="min-h-screen grid place-items-center p-6 text-center">Administration is temporarily unavailable.</main>;
  }
  const publishableKey = publishableKeyFromHost(window.location.hostname, configuredKey);
  return (
    <ClerkProvider
      publishableKey={publishableKey}
      proxyUrl={clerkProxyUrl}
      appearance={appearance}
      signInUrl={`${basePath}/admin`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <AdminRoutes />
    </ClerkProvider>
  );
}