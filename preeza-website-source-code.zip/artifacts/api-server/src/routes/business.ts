import { Router, type IRouter } from "express";
import { and, count, desc, eq, inArray } from "drizzle-orm";
import { db, enquiries, news, newsTranslations, productTranslations, products, services } from "@workspace/db";
import {
  CreateEnquiryBody, CreateEnquiryHeader, CreateNewsBody, CreateProductBody, CreateServiceBody,
  GetNewsParams, GetProductParams,
  ListEnquiriesQueryParams, ListNewsQueryParams, ListProductsQueryParams,
  UpdateEnquiryStatusBody, UpdateEnquiryStatusParams, UpdateProductBody,
} from "@workspace/api-zod";
import { requireAdmin } from "../middleware/auth";
import { isPublished, parseLocale } from "./localization";

const router: IRouter = Router();
const clean = (value: string) => value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim();
const sanitizeEnquiry = (input: ReturnType<typeof CreateEnquiryBody.parse>) => ({
  name: clean(input.name),
  company: clean(input.company),
  email: clean(input.email).toLowerCase(),
  phone: clean(input.phone),
  country: clean(input.country),
  subject: clean(input.subject),
  quantity: clean(input.quantity),
  message: clean(input.message),
});
const serializeArticle = <T extends { publishedAt: Date }>(row: T) => ({ ...row, publishedAt: row.publishedAt.toISOString() });
const serializeEnquiry = <T extends { createdAt: Date; idempotencyKey: string }>(row: T) => {
  const { idempotencyKey: _, ...safe } = row;
  return { ...safe, createdAt: row.createdAt.toISOString() };
};

router.get("/products", async (req, res, next) => {
  try {
    const query = ListProductsQueryParams.parse(req.query);
    const locale = parseLocale(req.query.lang || req.header("Accept-Language"));
    const rows = query.featured === undefined
      ? await db.select().from(products).orderBy(products.category, products.name).limit(100)
      : await db.select().from(products).where(eq(products.featured, query.featured)).orderBy(products.name).limit(100);
    const localized = locale === "en"
      ? []
      : await db.select().from(productTranslations).where(and(eq(productTranslations.locale, locale), inArray(productTranslations.productId, rows.map((row) => row.id))));
    const byProduct = new Map(localized.filter((row) => isPublished(row.status)).map((row) => [row.productId, row]));
    res.setHeader("Cache-Control", "public, max-age=60, stale-while-revalidate=600");
    res.json(rows.map((row) => {
      const translation = byProduct.get(row.id);
      return translation ? { ...row, ...translation, id: row.id, imageUrl: row.imageUrl, featured: row.featured, slug: row.slug, translationLanguage: locale, translationFallback: false } : { ...row, translationLanguage: "en", translationFallback: locale !== "en" };
    }));
  } catch (error) { next(error); }
});

router.get("/products/:slug", async (req, res, next) => {
  try {
    const { slug } = GetProductParams.parse(req.params);
    const locale = parseLocale(req.query.lang || req.header("Accept-Language"));
    const [row] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    if (!row) return void res.status(404).json({ error: "Product not found" });
    if (locale === "en") return void res.json({ ...row, translationLanguage: "en", translationFallback: false });
    const [translation] = await db.select().from(productTranslations).where(and(eq(productTranslations.productId, row.id), eq(productTranslations.locale, locale), eq(productTranslations.status, "published"))).limit(1);
    res.json(translation ? { ...row, ...translation, id: row.id, imageUrl: row.imageUrl, featured: row.featured, slug: row.slug, translationLanguage: locale, translationFallback: false } : { ...row, translationLanguage: "en", translationFallback: true });
  } catch (error) { next(error); }
});

router.post("/products", requireAdmin, async (req, res, next) => {
  try {
    const input = CreateProductBody.parse(req.body);
    const [row] = await db.insert(products).values(input).returning();
    res.status(201).json(row);
  } catch (error) { next(error); }
});

router.patch("/products/:slug", requireAdmin, async (req, res, next) => {
  try {
    const input = UpdateProductBody.parse(req.body);
    if (Object.keys(input).length === 0) return void res.status(400).json({ error: "Provide at least one field to update." });
    const { slug } = GetProductParams.parse(req.params);
    const [row] = await db.update(products).set(input).where(eq(products.slug, slug)).returning();
    if (!row) return void res.status(404).json({ error: "Product not found" });
    res.json(row);
  } catch (error) { next(error); }
});

router.delete("/products/:slug", requireAdmin, async (req, res, next) => {
  try {
    const { slug } = GetProductParams.parse(req.params);
    const [deleted] = await db.delete(products).where(eq(products.slug, slug)).returning({ id: products.id });
    if (!deleted) return void res.status(404).json({ error: "Product not found" });
    res.status(204).end();
  } catch (error) { next(error); }
});

router.get("/services", async (_req, res, next) => {
  try { res.json(await db.select().from(services).orderBy(services.id).limit(100)); } catch (error) { next(error); }
});

router.post("/services", requireAdmin, async (req, res, next) => {
  try {
    const input = CreateServiceBody.parse(req.body);
    const [row] = await db.insert(services).values(input).returning();
    res.status(201).json(row);
  } catch (error) { next(error); }
});

router.get("/news", async (req, res, next) => {
  try {
    const query = ListNewsQueryParams.parse(req.query);
    const locale = parseLocale(req.query.lang || req.header("Accept-Language"));
    const rows = query.featured === undefined
      ? await db.select().from(news).orderBy(desc(news.publishedAt)).limit(100)
      : await db.select().from(news).where(eq(news.featured, query.featured)).orderBy(desc(news.publishedAt)).limit(100);
    const localized = locale === "en"
      ? []
      : await db.select().from(newsTranslations).where(and(eq(newsTranslations.locale, locale), inArray(newsTranslations.newsId, rows.map((row) => row.id))));
    const byNews = new Map(localized.filter((row) => isPublished(row.status)).map((row) => [row.newsId, row]));
    res.setHeader("Cache-Control", "public, max-age=60, stale-while-revalidate=600");
    res.json(rows.map((row) => {
      const translation = byNews.get(row.id);
      return serializeArticle(translation ? { ...row, ...translation, id: row.id, imageUrl: row.imageUrl, featured: row.featured, publishedAt: row.publishedAt, slug: translation.slug } : { ...row, translationLanguage: "en", translationFallback: locale !== "en" });
    }));
  } catch (error) { next(error); }
});

router.get("/news/:slug", async (req, res, next) => {
  try {
    const { slug } = GetNewsParams.parse(req.params);
    const locale = parseLocale(req.query.lang || req.header("Accept-Language"));
    const [row] = await db.select().from(news).where(eq(news.slug, slug)).limit(1);
    if (!row) return void res.status(404).json({ error: "Article not found" });
    if (locale === "en") return void res.json(serializeArticle({ ...row, translationLanguage: "en", translationFallback: false }));
    const [translation] = await db.select().from(newsTranslations).where(and(eq(newsTranslations.newsId, row.id), eq(newsTranslations.locale, locale), eq(newsTranslations.status, "published"))).limit(1);
    res.json(serializeArticle(translation ? { ...row, ...translation, id: row.id, imageUrl: row.imageUrl, featured: row.featured, publishedAt: row.publishedAt } : { ...row, translationLanguage: "en", translationFallback: true }));
  } catch (error) { next(error); }
});

router.post("/news", requireAdmin, async (req, res, next) => {
  try {
    const input = CreateNewsBody.parse(req.body);
    const [row] = await db.insert(news).values(input).returning();
    res.status(201).json(serializeArticle(row!));
  } catch (error) { next(error); }
});

router.post("/enquiries", async (req, res, next) => {
  try {
    const { "Idempotency-Key": idempotencyKey } = CreateEnquiryHeader.parse({
      "Idempotency-Key": req.header("Idempotency-Key"),
    });
    const input = CreateEnquiryBody.parse(req.body);
    const [existing] = await db.select().from(enquiries).where(eq(enquiries.idempotencyKey, idempotencyKey)).limit(1);
    if (existing) return void res.json({ enquiryId: existing.enquiryId, message: "Your enquiry has already been received." });
    const sanitized = sanitizeEnquiry(input);
    const enquiryId = await db.transaction(async (tx) => {
      const [created] = await tx.insert(enquiries).values({
        ...sanitized,
        enquiryId: `pending:${idempotencyKey}`,
        idempotencyKey,
      }).returning({ id: enquiries.id });
      const publicId = `PG-ENQ-${new Date().getFullYear()}-${String(created.id).padStart(4, "0")}`;
      await tx.update(enquiries).set({ enquiryId: publicId }).where(eq(enquiries.id, created.id));
      return publicId;
    });
    res.status(201).json({ enquiryId, message: "Thank you. Our trade team will contact you shortly." });
  } catch (error) { next(error); }
});

router.get("/enquiries", requireAdmin, async (req, res, next) => {
  try {
    const query = ListEnquiriesQueryParams.parse(req.query);
    const rows = query.status
      ? await db.select().from(enquiries).where(eq(enquiries.status, query.status)).orderBy(desc(enquiries.createdAt)).limit(500)
      : await db.select().from(enquiries).orderBy(desc(enquiries.createdAt)).limit(500);
    res.json(rows.map(serializeEnquiry));
  } catch (error) { next(error); }
});

router.patch("/enquiries/:id/status", requireAdmin, async (req, res, next) => {
  try {
    const input = UpdateEnquiryStatusBody.parse(req.body);
    const { id } = UpdateEnquiryStatusParams.parse(req.params);
    if (id < 1) return void res.status(400).json({ error: "Invalid enquiry identifier" });
    const [row] = await db.update(enquiries).set(input).where(eq(enquiries.id, id)).returning();
    if (!row) return void res.status(404).json({ error: "Enquiry not found" });
    res.json(serializeEnquiry(row));
  } catch (error) { next(error); }
});

router.get("/dashboard/summary", requireAdmin, async (_req, res, next) => {
  try {
    const [[p], [s], [a], [e], [n]] = await Promise.all([
      db.select({ value: count() }).from(products), db.select({ value: count() }).from(services),
      db.select({ value: count() }).from(news), db.select({ value: count() }).from(enquiries),
      db.select({ value: count() }).from(enquiries).where(eq(enquiries.status, "new")),
    ]);
    res.json({ products: Number(p.value), services: Number(s.value), articles: Number(a.value), enquiries: Number(e.value), newEnquiries: Number(n.value) });
  } catch (error) { next(error); }
});

export default router;