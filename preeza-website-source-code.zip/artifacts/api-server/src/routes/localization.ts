import { Router, type IRouter, type Request } from "express";
import { and, eq, inArray, like, or } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import {
  db,
  languages,
  news,
  newsTranslations,
  productTranslations,
  products,
  translationKeys,
} from "@workspace/db";
import { requireAdmin } from "../middleware/auth";

const router: IRouter = Router();
const DEFAULT_LOCALE = "en";
const LOCALE_PATTERN = /^[a-z]{2,3}(?:-[A-Z][a-z]{2})?(?:-[A-Z]{2}|-\d{3})?$/;

const languageSeed = [
  ["en", "English", "English", "ltr", true, true, 0],
  ["hi", "Hindi", "हिन्दी", "ltr", true, false, 1],
  ["mr", "Marathi", "मराठी", "ltr", true, false, 2],
  ["ar", "Arabic", "العربية", "rtl", true, false, 3],
  ["fr", "French", "Français", "ltr", true, false, 4],
  ["es", "Spanish", "Español", "ltr", true, false, 5],
  ["de", "German", "Deutsch", "ltr", true, false, 6],
  ["ja", "Japanese", "日本語", "ltr", true, false, 7],
  ["zh", "Chinese", "中文", "ltr", true, false, 8],
  ["pt", "Portuguese", "Português", "ltr", true, false, 9],
  ["it", "Italian", "Italiano", "ltr", true, false, 10],
  ["ru", "Russian", "Русский", "ltr", true, false, 11],
  ["ur", "Urdu", "اردو", "rtl", true, false, 12],
] as const;

function parseLocale(value: unknown) {
  const locale = typeof value === "string" ? value.trim() : DEFAULT_LOCALE;
  if (!LOCALE_PATTERN.test(locale)) return DEFAULT_LOCALE;
  return locale.toLowerCase();
}

function isPublished(status: string) {
  return status === "published";
}

async function ensureLanguageSeed() {
  const existing = await db.select({ id: languages.id }).from(languages).limit(1);
  if (existing.length > 0) return;
  await db.insert(languages).values(languageSeed.map(([code, name, nativeName, direction, enabled, isDefault, sortOrder]) => ({
    code,
    name,
    nativeName,
    direction,
    enabled,
    isDefault,
    sortOrder,
  })));
}

function serializeArticle<T extends { publishedAt: Date }>(row: T) {
  return { ...row, publishedAt: row.publishedAt.toISOString() };
}

function getAdminUserId(req: Request) {
  return getAuth(req).userId || "admin";
}

router.get("/languages", async (_req, res, next) => {
  try {
    await ensureLanguageSeed();
    res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=3600");
    res.json(await db.select().from(languages).where(eq(languages.enabled, true)).orderBy(languages.sortOrder, languages.name));
  } catch (error) {
    next(error);
  }
});

router.get("/translations", async (req, res, next) => {
  try {
    const locale = parseLocale(req.query.locale);
    const rows = await db.select({
      key: translationKeys.key,
      value: translationKeys.value,
      namespace: translationKeys.namespace,
    }).from(translationKeys).where(and(
      eq(translationKeys.locale, locale),
      eq(translationKeys.status, "published"),
    ));
    const messages = Object.fromEntries(rows.map((row) => [row.key, row.value]));
    res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=3600");
    res.json({ locale, messages });
  } catch (error) {
    next(error);
  }
});

router.get("/admin/languages", requireAdmin, async (_req, res, next) => {
  try {
    await ensureLanguageSeed();
    res.json(await db.select().from(languages).orderBy(languages.sortOrder, languages.name));
  } catch (error) {
    next(error);
  }
});

router.patch("/admin/languages/:code", requireAdmin, async (req, res, next) => {
  try {
    const code = parseLocale(req.params.code);
    const [row] = await db.update(languages).set({
      enabled: typeof req.body.enabled === "boolean" ? req.body.enabled : undefined,
      direction: req.body.direction === "rtl" ? "rtl" : req.body.direction === "ltr" ? "ltr" : undefined,
      sortOrder: Number.isInteger(req.body.sortOrder) ? req.body.sortOrder : undefined,
      updatedAt: new Date(),
    }).where(eq(languages.code, code)).returning();
    if (!row) return void res.status(404).json({ error: "Language not found" });
    res.json(row);
  } catch (error) {
    next(error);
  }
});

router.get("/admin/translations", requireAdmin, async (req, res, next) => {
  try {
    const locale = parseLocale(req.query.locale);
    const query = typeof req.query.query === "string" ? req.query.query.trim() : "";
    const filter = query
      ? and(eq(translationKeys.locale, locale), or(like(translationKeys.key, `%${query}%`), like(translationKeys.value, `%${query}%`)))
      : eq(translationKeys.locale, locale);
    res.json(await db.select().from(translationKeys).where(filter).orderBy(translationKeys.key).limit(1000));
  } catch (error) {
    next(error);
  }
});

router.put("/admin/translations/:locale/:key", requireAdmin, async (req, res, next) => {
  try {
    const locale = parseLocale(String(req.params.locale));
    const key = String(req.params.key);
    const value = typeof req.body.value === "string" ? req.body.value.trim() : "";
    if (!key || !value) return void res.status(400).json({ error: "A translation key and value are required." });
    const [row] = await db.insert(translationKeys).values({
      key,
      locale,
      value,
      namespace: typeof req.body.namespace === "string" ? req.body.namespace : "common",
      status: req.body.status === "draft" ? "draft" : "published",
      updatedBy: getAdminUserId(req),
    }).onConflictDoUpdate({
      target: [translationKeys.locale, translationKeys.key],
      set: {
        value,
        namespace: typeof req.body.namespace === "string" ? req.body.namespace : "common",
        status: req.body.status === "draft" ? "draft" : "published",
        updatedBy: getAdminUserId(req),
        updatedAt: new Date(),
      },
    }).returning();
    res.json(row);
  } catch (error) {
    next(error);
  }
});

router.delete("/admin/translations/:locale/:key", requireAdmin, async (req, res, next) => {
  try {
    await db.delete(translationKeys).where(and(
      eq(translationKeys.locale, parseLocale(req.params.locale)),
      eq(translationKeys.key, String(req.params.key)),
    ));
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

router.get("/admin/products/:slug/translations", requireAdmin, async (req, res, next) => {
  try {
    const slug = String(req.params.slug);
    const [product] = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug)).limit(1);
    if (!product) return void res.status(404).json({ error: "Product not found" });
    res.json(await db.select().from(productTranslations).where(eq(productTranslations.productId, product.id)).orderBy(productTranslations.locale));
  } catch (error) {
    next(error);
  }
});

router.put("/admin/products/:slug/translations/:locale", requireAdmin, async (req, res, next) => {
  try {
    const locale = parseLocale(String(req.params.locale));
    const slug = String(req.params.slug);
    const [product] = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug)).limit(1);
    if (!product) return void res.status(404).json({ error: "Product not found" });
    const [row] = await db.insert(productTranslations).values({
      productId: product.id,
      locale,
      name: String(req.body.name || ""),
      description: String(req.body.description || ""),
      specifications: Array.isArray(req.body.specifications) ? req.body.specifications.map(String) : [],
      category: String(req.body.category || ""),
      origin: String(req.body.origin || ""),
      markets: Array.isArray(req.body.markets) ? req.body.markets.map(String) : [],
      quality: String(req.body.quality || ""),
      status: req.body.status === "draft" ? "draft" : "published",
      updatedBy: getAdminUserId(req),
    }).onConflictDoUpdate({
      target: [productTranslations.productId, productTranslations.locale],
      set: {
        name: String(req.body.name || ""),
        description: String(req.body.description || ""),
        specifications: Array.isArray(req.body.specifications) ? req.body.specifications.map(String) : [],
        category: String(req.body.category || ""),
        origin: String(req.body.origin || ""),
        markets: Array.isArray(req.body.markets) ? req.body.markets.map(String) : [],
        quality: String(req.body.quality || ""),
        status: req.body.status === "draft" ? "draft" : "published",
        updatedBy: getAdminUserId(req),
        updatedAt: new Date(),
      },
    }).returning();
    res.json(row);
  } catch (error) {
    next(error);
  }
});

router.get("/admin/news/:slug/translations", requireAdmin, async (req, res, next) => {
  try {
    const slug = String(req.params.slug);
    const [article] = await db.select({ id: news.id }).from(news).where(eq(news.slug, slug)).limit(1);
    if (!article) return void res.status(404).json({ error: "Article not found" });
    res.json(await db.select().from(newsTranslations).where(eq(newsTranslations.newsId, article.id)).orderBy(newsTranslations.locale));
  } catch (error) {
    next(error);
  }
});

router.put("/admin/news/:slug/translations/:locale", requireAdmin, async (req, res, next) => {
  try {
    const locale = parseLocale(String(req.params.locale));
    const slug = String(req.params.slug);
    const [article] = await db.select({ id: news.id }).from(news).where(eq(news.slug, slug)).limit(1);
    if (!article) return void res.status(404).json({ error: "Article not found" });
    const [row] = await db.insert(newsTranslations).values({
      newsId: article.id,
      locale,
      title: String(req.body.title || ""),
      slug: String(req.body.slug || slug),
      excerpt: String(req.body.excerpt || ""),
      body: String(req.body.body || ""),
      status: req.body.status === "draft" ? "draft" : "published",
      updatedBy: getAdminUserId(req),
    }).onConflictDoUpdate({
      target: [newsTranslations.newsId, newsTranslations.locale],
      set: {
        title: String(req.body.title || ""),
        slug: String(req.body.slug || slug),
        excerpt: String(req.body.excerpt || ""),
        body: String(req.body.body || ""),
        status: req.body.status === "draft" ? "draft" : "published",
        updatedBy: getAdminUserId(req),
        updatedAt: new Date(),
      },
    }).returning();
    res.json(row);
  } catch (error) {
    next(error);
  }
});

export { DEFAULT_LOCALE, parseLocale, isPublished };
export default router;