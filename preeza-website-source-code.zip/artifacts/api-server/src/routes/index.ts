import { Router, type IRouter } from "express";
import healthRouter from "./health";
import businessRouter from "./business";
import localizationRouter from "./localization";

const router: IRouter = Router();

router.use(healthRouter);
router.use(localizationRouter);
router.use(businessRouter);

export default router;
