import express, { type Express } from "express";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});
app.use(express.json({ limit: "64kb" }));
app.use(express.urlencoded({ extended: false, limit: "64kb" }));
app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

app.get("/api/sitemap.xml", (req, res) => {
  const origin = `${req.protocol}://${req.get("host")}`;
  const routes = [
    "/", "/about", "/products", "/services", "/industries", "/global-markets",
    "/quality-compliance", "/why-preeza", "/company-profile", "/insights", "/contact",
  ];
  const urls = routes.map((path) => `<url><loc>${origin}${path}</loc></url>`).join("");
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`);
});

const enquiryAttempts = new Map<string, { count: number; resetAt: number }>();
app.use("/api/enquiries", (req, res, next) => {
  if (req.method !== "POST") return next();
  const now = Date.now();
  if (enquiryAttempts.size > 10_000) {
    for (const [address, value] of enquiryAttempts) {
      if (value.resetAt <= now) enquiryAttempts.delete(address);
    }
  }
  const key = req.ip || "unknown";
  const current = enquiryAttempts.get(key);
  if (!current || current.resetAt <= now) {
    enquiryAttempts.set(key, { count: 1, resetAt: now + 60_000 });
    return next();
  }
  if (current.count >= 10) {
    res.setHeader("Retry-After", String(Math.ceil((current.resetAt - now) / 1000)));
    return void res.status(429).json({ error: "Too many submissions. Please wait a moment and try again." });
  }
  current.count += 1;
  next();
});

app.use("/api", router);

app.use((error: unknown, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const issue = error as { name?: string; code?: string; type?: string; status?: number };
  req.log.error({ name: issue.name, code: issue.code, requestId: req.id }, "Request failed");
  if (issue.name === "ZodError") return void res.status(400).json({ error: "Please check the submitted information." });
  if (issue.type === "entity.parse.failed") return void res.status(400).json({ error: "The request body is not valid JSON." });
  if (issue.type === "entity.too.large") return void res.status(413).json({ error: "The submitted information is too large." });
  if (issue.code === "23505") return void res.status(409).json({ error: "A record with these details already exists." });
  res.status(500).json({ error: "We could not complete this request. Please try again." });
});

export default app;
