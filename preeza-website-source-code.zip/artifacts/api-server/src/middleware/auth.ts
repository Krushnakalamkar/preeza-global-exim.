import { getAuth } from "@clerk/express";
import type { Request, Response, NextFunction } from "express";

type Claims = Record<string, unknown> & {
  metadata?: Record<string, unknown>;
  publicMetadata?: Record<string, unknown>;
  privateMetadata?: Record<string, unknown>;
};

function configuredAdminIds() {
  return new Set(
    (process.env.ADMIN_USER_IDS || "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean),
  );
}

export function isAdminRequest(req: Request) {
  const auth = getAuth(req);
  if (!auth.userId) return false;
  const claims = (auth.sessionClaims || {}) as Claims;
  const metadata = {
    ...(claims.metadata || {}),
    ...(claims.publicMetadata || {}),
    ...(claims.privateMetadata || {}),
  };
  return configuredAdminIds().has(auth.userId)
    || metadata.role === "admin"
    || metadata.admin === true;
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const auth = getAuth(req);
  if (!auth.userId) {
    return void res.status(401).json({ error: "Administrator sign-in required" });
  }
  if (!isAdminRequest(req)) {
    return void res.status(403).json({ error: "Administrator access is required" });
  }
  return next();
}